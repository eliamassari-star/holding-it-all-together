# Importazione sicura su GitHub

Questo archivio contiene il **progetto estratto**, non un file ZIP da inserire nel repository.

## Importare con Codex Cloud

1. Aprire Codex e scegliere `eliamassari-star/holding-it-all-together`.
2. Allegare questo archivio al task Codex (se l’interfaccia supporta gli allegati), oppure rendere il sorgente disponibile nell’ambiente di lavoro.
3. Chiedere di estrarre `holding-it-all-together/` direttamente nella radice del repository, senza annidare una seconda cartella.
4. Escludere `.env`, `.dev.vars`, chiavi, token, `node_modules` e cartelle build.
5. Avviare `pnpm install --frozen-lockfile` e `pnpm typecheck`; creare una PR invece di pubblicare immediatamente.

## Verifiche preliminari

- Il ramo `main` è attualmente incompleto: contiene solo file di configurazione.
- La pipeline `.github/workflows/quality.yml` esegue il controllo TypeScript su PR e push.
- Le credenziali per database, newsletter e AI vanno impostate come secret dell’hosting, mai committate.
- Verificare che i dati e gli URL dimostrativi siano sostituiti prima di andare online.

L'esportazione non modifica il sito pubblicato su ChatGPT Sites.
