import { accountAction } from '../../../../lib/newsletter';
import { recordConsent } from '../../../../lib/newsletter-consent';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export async function POST(request: Request) { try { const body = await request.json() as Record<string, unknown>; const email = String(body.email || '').trim().toLowerCase(); if (!emailPattern.test(email)) return Response.json({ message: 'Email non valida.' }, { status: 400 }); await accountAction('preferences', { ...body, email }); await recordConsent({ email, event: 'preferences_updated', source: 'preferences_page', trackingConsent: body.tracking === 'yes' }); return Response.json({ ok: true }); } catch { return Response.json({ message: 'Impossibile aggiornare le preferenze.' }, { status: 500 }); } }
