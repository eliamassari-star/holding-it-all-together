import { accountAction } from '@/lib/newsletter';
import { recordConsent, verifyUnsubscribeToken } from '@/lib/newsletter-consent';

export async function POST(request: Request) {
  try {
    const url = new URL(request.url);
    const contentType = request.headers.get('content-type') || '';
    const body = contentType.includes('application/json') ? await request.json() as Record<string, unknown> : Object.fromEntries((await request.formData()).entries());
    const token = String(body.token || url.searchParams.get('token') || '');
    const email = await verifyUnsubscribeToken(token);
    if (!email) return new Response(null, { status: 400 });
    await accountAction('unsubscribe', { email, oneClick: true });
    await recordConsent({ email, event: 'unsubscribed', source: 'list_unsubscribe_one_click', trackingConsent: false });
    return new Response(null, { status: 204 });
  } catch { return new Response(null, { status: 500 }); }
}
