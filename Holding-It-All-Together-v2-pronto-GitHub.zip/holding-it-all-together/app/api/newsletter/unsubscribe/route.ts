import { accountAction } from '../../../../lib/newsletter';
import { recordConsent } from '../../../../lib/newsletter-consent';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export async function POST(request: Request) { try { const body = await request.json() as Record<string, unknown>; const email = String(body.email || '').trim().toLowerCase(); if (!emailPattern.test(email)) return Response.json({ message: 'Email non valida.' }, { status: 400 }); await accountAction('unsubscribe', { email }); await recordConsent({ email, event: 'unsubscribed', source: 'unsubscribe_page', trackingConsent: false }); return Response.json({ ok: true }); } catch { return Response.json({ message: 'Impossibile completare la disiscrizione.' }, { status: 500 }); } }
