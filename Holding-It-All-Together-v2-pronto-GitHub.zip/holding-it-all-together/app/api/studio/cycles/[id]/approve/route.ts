import { editorFromRequest, unauthorizedResponse } from '@/lib/editorial/auth';
import { approveCycle } from '@/lib/editorial/repository';
import type { PublicationChannel } from '@/lib/editorial/types';

const allowed = new Set<PublicationChannel>(['site', 'newsletter', 'podcast_bundle']);

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const editor = editorFromRequest(request);
  if (!editor) return unauthorizedResponse();
  try {
    const body = await request.json() as { channels?: string[]; notes?: string };
    const channels = (body.channels || []).filter((item): item is PublicationChannel => allowed.has(item as PublicationChannel));
    return Response.json(await approveCycle((await params).id, channels, body.notes || '', editor.userId));
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Approvazione non riuscita.' }, { status: 409 });
  }
}
