import { runEditorialAgent } from '@/lib/editorial/ai';
import { editorFromRequest, unauthorizedResponse } from '@/lib/editorial/auth';
import { getCyclePackage, publishApprovedCycle } from '@/lib/editorial/repository';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const editor = editorFromRequest(request);
  if (!editor) return unauthorizedResponse();
  try {
    const { id } = await params;
    const pack = await getCyclePackage(id);
    const distribution = await runEditorialAgent('publisher', pack.cycle, pack.artifacts);
    return Response.json({ ...(await publishApprovedCycle(id, distribution, editor.userId)), lastResult: distribution });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Pubblicazione non riuscita.' }, { status: 500 });
  }
}
