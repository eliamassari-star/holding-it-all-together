import { editorFromRequest, unauthorizedResponse } from '@/lib/editorial/auth';
import { getCyclePackage } from '@/lib/editorial/repository';

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!editorFromRequest(request)) return unauthorizedResponse();
  try { return Response.json(await getCyclePackage((await params).id)); }
  catch (error) { return Response.json({ error: error instanceof Error ? error.message : 'Ciclo non trovato.' }, { status: 404 }); }
}
