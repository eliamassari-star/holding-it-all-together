import { runEditorialAgent } from '@/lib/editorial/ai';
import { workflowAgentForState } from '@/lib/editorial/agents';
import { editorFromRequest, unauthorizedResponse } from '@/lib/editorial/auth';
import { beginAgentRun, completeAgentRun, failAgentRun, getCyclePackage } from '@/lib/editorial/repository';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!editorFromRequest(request)) return unauthorizedResponse();
  const { id } = await params;
  let runId: string | null = null;
  try {
    const pack = await getCyclePackage(id);
    const agentKey = workflowAgentForState[pack.cycle.state];
    if (!agentKey || agentKey === 'publisher') return Response.json({ error: 'Questo passaggio richiede un’azione dedicata.' }, { status: 409 });
    runId = await beginAgentRun(id, agentKey);
    const result = await runEditorialAgent(agentKey, pack.cycle, pack.artifacts);
    const updated = await completeAgentRun(id, runId, agentKey, result);
    return Response.json({ ...updated, lastResult: result });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Esecuzione agente non riuscita.';
    if (runId) await failAgentRun(id, runId, message);
    return Response.json({ error: message }, { status: 500 });
  }
}
