import { editorFromRequest, unauthorizedResponse } from '@/lib/editorial/auth';
import { createCycle, listCycles } from '@/lib/editorial/repository';

export async function GET(request: Request) {
  if (!editorFromRequest(request)) return unauthorizedResponse();
  try { return Response.json({ cycles: await listCycles() }); }
  catch (error) { return Response.json({ error: error instanceof Error ? error.message : 'Database non disponibile.' }, { status: 500 }); }
}

export async function POST(request: Request) {
  const editor = editorFromRequest(request);
  if (!editor) return unauthorizedResponse();
  try {
    const body = await request.json() as { topic?: string; category?: string; promise?: string };
    if (!body.topic?.trim()) return Response.json({ error: 'Inserisci un argomento.' }, { status: 400 });
    const cycle = await createCycle({ topic: body.topic, category: body.category || 'Organizzazione', promise: body.promise }, editor.userId);
    return Response.json(cycle, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Impossibile creare il ciclo.' }, { status: 500 });
  }
}
