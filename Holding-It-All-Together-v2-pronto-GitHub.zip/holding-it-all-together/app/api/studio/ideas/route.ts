import { generateIdeas } from '@/lib/editorial/ai';
import { editorFromRequest, unauthorizedResponse } from '@/lib/editorial/auth';

export async function POST(request: Request) {
  if (!editorFromRequest(request)) return unauthorizedResponse();
  try {
    const body = await request.json() as { seed?: string; category?: string };
    const result = await generateIdeas(body.seed?.trim() || '', body.category || 'Organizzazione');
    return Response.json({ result });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Impossibile generare le idee.' }, { status: 500 });
  }
}
