import { subscribe } from '../../../lib/newsletter';
import { isSuppressed, recordConsent } from '../../../lib/newsletter-consent';

const attempts = new Map<string, { count: number; resetAt: number }>();
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: Request) {
  const ip = request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || 'local';
  const now = Date.now(); const current = attempts.get(ip);
  if (current && current.resetAt > now && current.count >= 5) return Response.json({ message: 'Troppi tentativi. Riprova tra qualche minuto.' }, { status: 429 });
  attempts.set(ip, !current || current.resetAt <= now ? { count: 1, resetAt: now + 10 * 60_000 } : { ...current, count: current.count + 1 });
  try {
    const body = await request.json() as { email?: string; name?: string; privacy?: string; tracking?: string; website?: string };
    if (body.website) return Response.json({ message: 'Controlla la tua email per confermare l’iscrizione.' });
    const email = body.email?.trim().toLowerCase(); const name = body.name?.trim();
    if (!email || !emailPattern.test(email)) return Response.json({ message: 'Inserisci un indirizzo email valido.' }, { status: 400 });
    if (body.privacy !== 'accepted') return Response.json({ message: 'È necessario accettare la privacy policy.' }, { status: 400 });
    if (await isSuppressed(email)) return Response.json({ message: 'Questo indirizzo risulta disiscritto. Contatta la redazione per riattivarlo.' }, { status: 409 });
    await subscribe({ email, name, trackingConsent: body.tracking === 'accepted' });
    await recordConsent({ email, event: 'subscription_requested', source: 'website_modal', trackingConsent: body.tracking === 'accepted' });
    return Response.json({ message: 'Ti abbiamo inviato un’email: aprila per confermare l’iscrizione.' }, { status: 201 });
  } catch (error) {
    return Response.json({ message: error instanceof Error ? error.message : 'Qualcosa non ha funzionato.' }, { status: 500 });
  }
}
