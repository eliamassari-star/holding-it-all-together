import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';
import { siteConfig } from '../../config';
import { articles } from '../../data/content';
import { getArticle } from '../../../lib/editorial/public-content';

export function generateStaticParams() {
  return articles.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const article = await getArticle(slug);
  if (!article) return {};
  return {
    title: article.title,
    description: article.description,
    alternates: { canonical: `/articoli/${slug}` },
    openGraph: { type: 'article', title: article.title, description: article.description, images: [article.image] },
    twitter: { card: 'summary_large_image', title: article.title, description: article.description, images: [article.image] },
  };
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = await getArticle(slug);
  if (!article) notFound();
  const structured = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    description: article.description,
    image: `${siteConfig.url}${article.image}`,
    datePublished: '2024-12-12',
    author: { '@type': 'Organization', name: siteConfig.name },
    publisher: { '@type': 'Organization', name: siteConfig.name },
  };

  return (
    <>
      <Header />
      <main className="article-page">
        <div className="article-heading">
          <Link className="back-link" href="/articoli"><span aria-hidden="true">←</span> Tutti gli articoli</Link>
          <span className="category-label">{article.category}</span>
          <h1>{article.title}</h1>
          <p>{article.description}</p>
          <small>{article.date} · {article.readingTime}</small>
        </div>
        <img className="article-hero" src={article.image} style={{ objectPosition: article.imagePosition }} alt="" />
        <article className="prose">
          {article.body.map((paragraph, index) => index === 0 ? <p className="lead" key={paragraph}>{paragraph}</p> : <p key={paragraph}>{paragraph}</p>)}
          <blockquote>Una vita gestibile non è una vita vuota. È una vita in cui sappiamo che cosa proteggere.</blockquote>
          <h2>Da provare questa settimana</h2>
          <p>Scegli una sola idea e rendila abbastanza piccola da poterla iniziare oggi.</p>
        </article>
      </main>
      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structured) }} />
    </>
  );
}
