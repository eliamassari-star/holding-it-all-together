import type { Metadata } from 'next';
import { ArticleCard } from '../components/ArticleCard';
import { Footer } from '../components/Footer';
import { Header } from '../components/Header';
import { getArticles } from '../../lib/editorial/public-content';

export const metadata: Metadata = { title: 'Articoli', description: 'Storie vere e idee pratiche per una vita piena e più gestibile.', alternates: { canonical: '/articoli' } };

export const dynamic = 'force-dynamic';

export default async function ArticlesPage() {
  const articles = await getArticles();
  return <><Header /><main className="archive-page section-shell"><p className="eyebrow">Idee da usare davvero</p><h1>Articoli</h1><p className="page-lede">Lavoro, soldi, famiglia, benessere e organizzazione raccontati senza formule magiche.</p><div className="article-grid archive-grid">{articles.map((article) => <ArticleCard article={article} key={article.slug} />)}</div></main><Footer /></>;
}
