import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ArticleCard } from '../../components/ArticleCard';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';
import { categories } from '../../data/content';
import { getArticles } from '../../../lib/editorial/public-content';

export function generateStaticParams() { return categories.map(({ slug }) => ({ slug })); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> { const { slug } = await params; const category = categories.find((item) => item.slug === slug); return category ? { title: category.title, description: category.description.replace('\n', ' '), alternates: { canonical: `/categoria/${slug}` } } : {}; }

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const category = categories.find((item) => item.slug === slug); if (!category) notFound();
  const articles = await getArticles();
  const matches = articles.filter((article) => article.category.toLowerCase() === category.title.toLowerCase());
  return <><Header /><main className="archive-page section-shell"><p className="eyebrow">Categoria</p><h1>{category.title}</h1><p className="page-lede">{category.description.replace('\n', ' ')}</p><div className="article-grid archive-grid">{matches.length ? matches.map((article) => <ArticleCard article={article} key={article.slug} />) : <div className="empty-state"><h2>Stiamo preparando nuovi contenuti.</h2><p>Torna presto: questa sezione crescerà con storie e strumenti concreti.</p></div>}</div></main><Footer /></>;
}
