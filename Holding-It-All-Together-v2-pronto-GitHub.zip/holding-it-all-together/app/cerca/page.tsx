import type { Metadata } from 'next';
import { Footer } from '../components/Footer';
import { Header } from '../components/Header';
import { SearchClient, type SearchItem } from '../components/SearchClient';
import { getArticles, getNewsletterIssues, getPodcastEpisodes } from '../../lib/editorial/public-content';

export const metadata: Metadata = { title: 'Cerca', description: 'Cerca articoli, newsletter ed episodi podcast.', alternates: { canonical: '/cerca' } };

export const dynamic = 'force-dynamic';

export default async function SearchPage() {
  const [articles, newsletterIssues, podcastEpisodes] = await Promise.all([getArticles(), getNewsletterIssues(), getPodcastEpisodes()]);
  const items: SearchItem[] = [
    ...articles.map((item) => ({ type: 'Articolo', title: item.title, description: item.description, href: `/articoli/${item.slug}` })),
    ...newsletterIssues.map((item) => ({ type: `Newsletter ${item.number}`, title: item.title.replace('\n', ' '), description: item.seoDescription, href: `/newsletter/${item.slug}` })),
    ...podcastEpisodes.map((item) => ({ type: `Podcast ${item.number}`, title: item.title, description: item.description, href: `/podcast/${item.slug}` })),
  ];
  return <><Header /><main className="search-page"><p className="eyebrow">Tutto il progetto</p><h1>Cerca</h1><SearchClient items={items} /></main><Footer /></>;
}
