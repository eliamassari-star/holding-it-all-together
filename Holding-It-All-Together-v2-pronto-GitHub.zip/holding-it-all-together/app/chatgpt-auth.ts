import { headers } from 'next/headers';
import { redirect } from 'next/navigation';

export type ChatGPTUser = { userId: string; displayName: string; email: string; fullName: string | null };

const USER_ID_HEADER = 'oai-authenticated-user-id';
const USER_EMAIL_HEADER = 'oai-authenticated-user-email';
const USER_FULL_NAME_HEADER = 'oai-authenticated-user-full-name';
const USER_FULL_NAME_ENCODING_HEADER = 'oai-authenticated-user-full-name-encoding';

export async function getChatGPTUser(): Promise<ChatGPTUser | null> {
  const requestHeaders = await headers();
  const userId = requestHeaders.get(USER_ID_HEADER);
  const email = requestHeaders.get(USER_EMAIL_HEADER);
  if (!userId || !email) return null;
  const encodedName = requestHeaders.get(USER_FULL_NAME_HEADER);
  let fullName: string | null = null;
  if (encodedName && requestHeaders.get(USER_FULL_NAME_ENCODING_HEADER) === 'percent-encoded-utf-8') {
    try { fullName = decodeURIComponent(encodedName); } catch { fullName = null; }
  }
  return { userId, email, fullName, displayName: fullName || email };
}

export async function requireChatGPTUser(returnTo: string): Promise<ChatGPTUser> {
  const user = await getChatGPTUser();
  if (user) return user;
  const safeReturn = returnTo.startsWith('/') && !returnTo.startsWith('//') ? returnTo : '/studio';
  redirect(`/signin-with-chatgpt?return_to=${encodeURIComponent(safeReturn)}`);
}

export function isAuthorizedEditor(user: Pick<ChatGPTUser, 'userId' | 'email'>) {
  const ids = (process.env.EDITOR_USER_IDS || '').split(',').map((item) => item.trim()).filter(Boolean);
  const emails = (process.env.EDITOR_EMAILS || '').split(',').map((item) => item.trim().toLowerCase()).filter(Boolean);
  return ids.includes(user.userId) || emails.includes(user.email.toLowerCase());
}

export function localEditor(): ChatGPTUser | null {
  return process.env.NODE_ENV === 'production' ? null : { userId: 'local-editor', email: 'locale@holding.test', fullName: 'Editor locale', displayName: 'Editor locale' };
}
