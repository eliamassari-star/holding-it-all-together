import type { Metadata } from 'next';
import { Footer } from '../components/Footer';
import { Header } from '../components/Header';
import { SubscribeButton } from '../components/SubscribeButton';

export const metadata: Metadata = { title: 'Chi siamo', description: 'Il racconto senza filtri di una vita tra lavoro, conti, famiglia e tempo che manca.', alternates: { canonical: '/chi-siamo' } };

export default function AboutPage() { return <><Header /><main id="contenuto" className="about-page"><section><div><p className="eyebrow">Work. Money. Family. Life.</p><h1>La vita è complicata.<br />Raccontiamola per quella che è.</h1><p>Holding It All Together nasce per raccontare la vita quotidiana di chi è lavoratore, compagno e padre. La distanza da casa per lavoro, il tempo che manca con i figli, la fatica di chi resta a gestire tutto, le scelte economiche di ogni giorno.</p><p>Non vogliamo vendere il sogno di una vita perfetta. Vogliamo parlare di ciò che pesa, delle decisioni che prendiamo e degli strumenti che ci aiutano a non subirla. Gli articoli iniziali del sito sono contenuti di esempio: il racconto personale crescerà attraverso gli episodi pubblicati.</p><SubscribeButton>Unisciti alla community</SubscribeButton></div><img src="/images/home-hero.png" alt="Famiglia insieme al tramonto" /></section><blockquote>Non promettiamo equilibrio perfetto. Cerchiamo modi più umani di abitare le giornate.</blockquote></main><Footer /></>; }
