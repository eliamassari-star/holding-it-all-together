'use client';

import { FormEvent, useState } from 'react';

export function AccountActionForm({ action }: { action: 'preferences' | 'unsubscribe' }) {
  const [state, setState] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState('loading');
    const data = Object.fromEntries(new FormData(event.currentTarget));
    const response = await fetch(`/api/newsletter/${action}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    setState(response.ok ? 'success' : 'error');
  }
  if (state === 'success') return <div className="account-success"><span aria-hidden="true">✓</span><p>{action === 'unsubscribe' ? 'Disiscrizione registrata.' : 'Preferenze aggiornate.'}</p></div>;
  return (
    <form className="account-form" onSubmit={submit}>
      <label>Email<input name="email" type="email" required /></label>
      {action === 'preferences' && <><fieldset><legend>Cosa vuoi ricevere?</legend><label><input type="checkbox" name="weekly" value="yes" defaultChecked /> Newsletter del giovedì</label><label><input type="checkbox" name="podcast" value="yes" defaultChecked /> Nuovi episodi podcast</label></fieldset><fieldset><legend>Misurazione facoltativa</legend><label><input type="checkbox" name="tracking" value="yes" /> Consento la misurazione individuale di aperture e interazioni</label><small>Puoi disattivarla continuando a ricevere la newsletter.</small></fieldset></>}
      <button className="button" type="submit" disabled={state === 'loading'}>{state === 'loading' && <span className="spinner" />} {action === 'unsubscribe' ? 'Conferma disiscrizione' : 'Salva preferenze'}</button>
      {state === 'error' && <p className="form-error">Impossibile completare la richiesta. Riprova.</p>}
    </form>
  );
}
