import Link from 'next/link';
import type { Article } from '../data/content';

export function ArticleCard({ article }: { article: Article }) {
  return (
    <Link className="article-card" href={`/articoli/${article.slug}`}>
      <div className="article-image"><img src={article.image} style={{ objectPosition: article.imagePosition }} alt="" loading="lazy" /></div>
      <div className="article-card-body">
        <span className="category-label">{article.category}</span>
        <h3>{article.title}</h3>
        <p>{article.description}</p>
        <small>{article.readingTime}</small>
      </div>
    </Link>
  );
}
