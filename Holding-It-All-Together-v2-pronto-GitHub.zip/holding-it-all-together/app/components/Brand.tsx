import Link from 'next/link';

export function Brand({ light = false }: { light?: boolean }) {
  return (
    <Link className={`brand ${light ? 'brand-light' : ''}`} href="/" aria-label="Holding It All Together, home">
      <strong>Holding<br />It All Together</strong>
      <span>Work. Money. Family. Life.</span>
    </Link>
  );
}
