'use client';

import Link from 'next/link';
import { categories } from '../data/content';

const icons = ['▣', '◎', '⌂', '♡', '▦'];

export function CategoryNav() {
  return (
    <section className="categories" aria-label="Categorie">
      {categories.map((category, index) => <Link href={`/categoria/${category.slug}`} key={category.slug}><span className="category-icon" aria-hidden="true">{icons[index]}</span><strong>{category.title}</strong><small>{category.description.split('\n').map((line) => <span key={line}>{line}</span>)}</small></Link>)}
    </section>
  );
}

