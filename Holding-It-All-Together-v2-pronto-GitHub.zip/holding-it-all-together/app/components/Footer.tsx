'use client';

import Link from 'next/link';
import { siteConfig } from '../config';
import { Brand } from './Brand';

export function Footer() {
  return (
    <footer className="site-footer">
      <Brand />
      <nav aria-label="Navigazione footer"><Link href="/articoli">Articoli</Link><Link href="/podcast">Podcast</Link><Link href="/strumenti">Strumenti</Link><Link href="/chi-siamo">Chi siamo</Link></nav>
      <div className="footer-meta">
        <div className="social-row">
          <a href={siteConfig.socials.linkedin} aria-label="LinkedIn"><span>in</span></a>
          <a href={siteConfig.socials.instagram} aria-label="Instagram"><span>◎</span></a>
          <a href={siteConfig.socials.youtube} aria-label="YouTube"><span>▶</span></a>
        </div>
        <div className="legal-row"><Link href="/privacy">Privacy</Link><Link href="/cookie">Cookie</Link><Link href="/termini">Termini</Link></div>
      </div>
    </footer>
  );
}

