'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { Brand } from './Brand';
import { SubscribeButton } from './SubscribeButton';

const navItems = [['/', 'Home'], ['/articoli', 'Articoli'], ['/podcast', 'Podcast'], ['/strumenti', 'Strumenti'], ['/chi-siamo', 'Chi siamo']] as const;

export function Header() {
  const path = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <><a className="skip-link" href="#contenuto">Vai al contenuto</a><header className="site-header">
      <Brand />
      <nav aria-label="Navigazione principale">
        {navItems.map(([href, label]) => <Link className={path === href ? 'active' : ''} href={href} key={href}>{label}</Link>)}
      </nav>
      <div className="header-actions">
        <Link className="icon-link search-icon" href="/cerca" aria-label="Cerca">⌕</Link>
        <SubscribeButton className="button button-small">Iscriviti</SubscribeButton>
        <button className="menu-button" type="button" aria-label={menuOpen ? 'Chiudi menu' : 'Apri menu'} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(!menuOpen)}>
          <span aria-hidden="true">{menuOpen ? '×' : '☰'}</span>
        </button>
      </div>
      {menuOpen && (
        <div className="mobile-menu" id="mobile-navigation">
          <nav aria-label="Navigazione mobile">
            {navItems.map(([href, label]) => <Link href={href} key={href} onClick={() => setMenuOpen(false)}>{label}</Link>)}
            <Link href="/newsletter" onClick={() => setMenuOpen(false)}>Newsletter</Link>
            <Link href="/cerca" onClick={() => setMenuOpen(false)}>Cerca</Link>
          </nav>
          <SubscribeButton className="button button-wide">Iscriviti</SubscribeButton>
        </div>
      )}
    </header></>
  );
}

