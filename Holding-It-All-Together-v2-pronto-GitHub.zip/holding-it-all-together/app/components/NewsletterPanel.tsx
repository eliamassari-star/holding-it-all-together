'use client';

import Link from 'next/link';
import { siteConfig } from '../config';
import { articles, type NewsletterIssue } from '../data/content';
import { Brand } from './Brand';

export function NewsletterPanel({ issue }: { issue: NewsletterIssue }) {
  const linked = issue.linkedArticles.map((slug) => articles.find((article) => article.slug === slug)).filter(Boolean);
  return (
    <article className="newsletter-panel">
      <header className="newsletter-header"><Brand /><div><strong>{issue.number}</strong><time>{issue.date}</time></div></header>
      <div className="rule" />
      <section className="newsletter-intro"><h1>{issue.title.split('\n').map((line) => <span key={line}>{line}</span>)}</h1><p>{issue.introduction}</p></section>
      <img className="newsletter-hero-image" src={issue.heroImage} alt="Tazza, quaderno e una famiglia in una cucina illuminata dal sole" />
      <section className="newsletter-toc">
        <h2>In questo numero:</h2>
        {linked.map((article) => article && <Link href={`/articoli/${article.slug}`} key={article.slug}><img src={article.image} alt="" /><span><small>{article.category}</small><strong>{article.title}</strong></span><span aria-hidden="true">→</span></Link>)}
      </section>
      <Link className="button newsletter-read" href={`/newsletter/${issue.slug}`}>Leggi la newsletter completa <span aria-hidden="true">→</span></Link>
      <footer className="newsletter-footer">
        <Brand />
        <div><span>Unisciti alla community</span><div className="social-row"><a href={siteConfig.socials.youtube} aria-label="YouTube"><span>▶</span></a><a href={siteConfig.socials.instagram} aria-label="Instagram"><span>◎</span></a><a href={siteConfig.socials.linkedin} aria-label="LinkedIn"><span>in</span></a></div></div>
        <p><Link href="/newsletter/unsubscribe">Disiscriviti</Link><span>|</span><Link href="/newsletter/preferenze">Gestisci preferenze</Link></p>
      </footer>
    </article>
  );
}

