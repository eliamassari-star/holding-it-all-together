'use client';

import { siteConfig } from '../config';

export function PodcastLinks({ labels = false }: { labels?: boolean }) {
  return (
    <div className={`podcast-links ${labels ? 'with-labels' : ''}`}>
      <a className="spotify" href={siteConfig.socials.spotify} aria-label="Ascolta su Spotify"><span className="platform-mark">◉</span>{labels && <span>Spotify</span>}</a>
      <a className="apple" href={siteConfig.socials.apple} aria-label="Ascolta su Apple Podcasts"><span className="platform-symbol">◉</span>{labels && <span>Apple Podcasts</span>}</a>
      <a className="youtube" href={siteConfig.socials.youtube} aria-label="Guarda su YouTube"><span className="platform-symbol">▶</span>{labels && <span>YouTube</span>}</a>
    </div>
  );
}

