'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';

export type SearchItem = { type: string; title: string; description: string; href: string };

export function SearchClient({ items }: { items: SearchItem[] }) {
  const [query, setQuery] = useState('');
  const results = useMemo(() => {
    const term = query.trim().toLocaleLowerCase('it');
    if (!term) return [];
    return items.filter((item) => `${item.type} ${item.title} ${item.description}`.toLocaleLowerCase('it').includes(term));
  }, [items, query]);
  return (
    <section className="search-experience">
      <label><span className="search-glyph" aria-hidden="true">⌕</span><span className="sr-only">Cerca nel sito</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cerca articoli, newsletter, episodi…" autoFocus /></label>
      {query && <p className="result-count">{results.length ? `${results.length} risultati` : 'Nessun risultato. Prova con un’altra parola.'}</p>}
      <div className="search-results">{results.map((item) => <Link href={item.href} key={item.href}><span>{item.type}</span><h2>{item.title}</h2><p>{item.description}</p></Link>)}</div>
    </section>
  );
}

