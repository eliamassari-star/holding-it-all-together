'use client';

import { useMemo, useState } from 'react';
import type { AgentKey, CyclePackage, EditorialArtifact, EditorialCycle, PublicationChannel } from '@/lib/editorial/types';

type AgentSummary = { key: AgentKey; name: string; shortName: string; description: string; usesWeb: boolean };
type Playbook = Record<string, { title: string; rules: readonly string[]; sources: readonly { label: string; url: string }[] }>;
type Props = {
  initialCycles: EditorialCycle[];
  agents: AgentSummary[];
  playbook: Playbook;
  integrations: { ai: string; newsletter: string; distribution: string };
  editorName: string;
};

const stateLabels: Record<string, string> = {
  selected: 'Selezionato', brief_ready: 'Brief pronto', research_ready: 'Ricerca pronta', article_ready: 'Articolo pronto',
  podcast_ready: 'Podcast pronto', review_ready: 'Revisione pronta', changes_requested: 'Correzioni richieste',
  ready_for_approval: 'Da approvare', approved: 'Approvato', published: 'Pubblicato', archived: 'Misurato',
};

const categories = ['Lavoro', 'Soldi', 'Famiglia', 'Benessere', 'Organizzazione'];

export function StudioDashboard({ initialCycles, agents, playbook, integrations, editorName }: Props) {
  const [cycles, setCycles] = useState(initialCycles);
  const [selected, setSelected] = useState<CyclePackage | null>(null);
  const [topic, setTopic] = useState('');
  const [category, setCategory] = useState('Organizzazione');
  const [seed, setSeed] = useState('');
  const [ideas, setIdeas] = useState<Array<Record<string, string>>>([]);
  const [busy, setBusy] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [channels, setChannels] = useState<PublicationChannel[]>(['site']);
  const [preview, setPreview] = useState<'article' | 'podcast' | null>(null);

  const completedKinds = useMemo(() => new Set(selected?.artifacts.map((item) => item.kind) || []), [selected]);
  const articleArtifact = useMemo(() => latestArtifact(selected, 'article'), [selected]);
  const podcastArtifact = useMemo(() => latestArtifact(selected, 'podcast'), [selected]);
  const articleCounts = record(articleArtifact?.content.word_counts);
  const podcastCounts = record(podcastArtifact?.content.word_counts);

  async function api(path: string, init?: RequestInit) {
    setError(''); setMessage('');
    const response = await fetch(path, { ...init, headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) } });
    const payload = await response.json() as Record<string, unknown>;
    if (!response.ok) throw new Error(String(payload.error || 'Operazione non riuscita.'));
    return payload;
  }

  function syncPackage(pack: CyclePackage) {
    setPreview(null);
    setSelected(pack);
    setCycles((current) => [pack.cycle, ...current.filter((item) => item.id !== pack.cycle.id)]);
  }

  async function loadCycle(id: string) {
    setBusy(`load-${id}`);
    try { syncPackage(await api(`/api/studio/cycles/${id}`) as unknown as CyclePackage); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Errore.'); }
    finally { setBusy(''); }
  }

  async function create(event: React.FormEvent) {
    event.preventDefault(); setBusy('create');
    try {
      const pack = await api('/api/studio/cycles', { method: 'POST', body: JSON.stringify({ topic, category }) }) as unknown as CyclePackage;
      syncPackage(pack); setTopic(''); setMessage('Ciclo editoriale creato. Il Caporedattore può iniziare.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Errore.'); }
    finally { setBusy(''); }
  }

  async function findIdeas(event: React.FormEvent) {
    event.preventDefault(); setBusy('ideas');
    try {
      const payload = await api('/api/studio/ideas', { method: 'POST', body: JSON.stringify({ seed, category }) });
      const result = payload.result as { artifact?: { ideas?: Array<Record<string, string>> }; mode?: string };
      setIdeas(result.artifact?.ideas || []); setMessage(`Scout completato in modalità ${result.mode === 'live' ? 'AI con ricerca web' : 'dimostrativa'}.`);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Errore.'); }
    finally { setBusy(''); }
  }

  async function runNext() {
    if (!selected) return; setBusy('run');
    try {
      const payload = await api(`/api/studio/cycles/${selected.cycle.id}/run`, { method: 'POST' }) as unknown as CyclePackage & { lastResult?: { mode: string } };
      syncPackage(payload); setMessage(`Passaggio completato${payload.lastResult?.mode === 'demo' ? ' in modalità dimostrativa' : ''}.`);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Errore.'); }
    finally { setBusy(''); }
  }

  async function approve() {
    if (!selected) return; setBusy('approve');
    try {
      syncPackage(await api(`/api/studio/cycles/${selected.cycle.id}/approve`, { method: 'POST', body: JSON.stringify({ channels, notes: 'Approvato dallo Studio editoriale.' }) }) as unknown as CyclePackage);
      setMessage('Versione approvata. Il Publisher può preparare la pubblicazione.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Errore.'); }
    finally { setBusy(''); }
  }

  async function publish() {
    if (!selected) return; setBusy('publish');
    try {
      syncPackage(await api(`/api/studio/cycles/${selected.cycle.id}/publish`, { method: 'POST' }) as unknown as CyclePackage);
      setMessage('Contenuti pubblicati sul sito; i pacchetti esterni sono pronti per i canali configurati.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Errore.'); }
    finally { setBusy(''); }
  }

  return (
    <main className="studio">
      <header className="studio-topbar">
        <div><p className="eyebrow">Holding It All Together</p><h1>Redazione AI</h1></div>
        <div className="studio-user"><span className="status-dot" />{editorName}</div>
      </header>

      <section className="studio-status-grid" aria-label="Stato integrazioni">
        <Status label="Motore AI" value={integrations.ai} />
        <Status label="Newsletter" value={integrations.newsletter} />
        <Status label="Distribuzione" value={integrations.distribution} />
      </section>

      {message && <p className="studio-notice success">{message}</p>}
      {error && <p className="studio-notice error">{error}</p>}

      <section className="studio-section">
        <header><p className="eyebrow">La squadra</p><h2>Otto responsabilità, un solo flusso.</h2></header>
        <div className="agent-grid">
          {agents.map((agent, index) => <article className="agent-card" key={agent.key}><span>{String(index + 1).padStart(2, '0')}</span><h3>{agent.name}</h3><p>{agent.description}</p>{agent.usesWeb && <small>Ricerca web</small>}</article>)}
        </div>
      </section>

      <section className="studio-section scout-panel">
        <div><p className="eyebrow">Scout argomenti</p><h2>Cerca il prossimo tema.</h2><p>Inserisci una direzione iniziale. In modalità AI lo Scout consulta il web e restituisce cinque opportunità motivate.</p></div>
        <form onSubmit={findIdeas}><label>Direzione o domanda<input value={seed} onChange={(event) => setSeed(event.target.value)} placeholder="Es. Come proteggere il tempo familiare" /></label><label>Categoria<select value={category} onChange={(event) => setCategory(event.target.value)}>{categories.map((item) => <option key={item}>{item}</option>)}</select></label><button className="button" disabled={busy === 'ideas'}>{busy === 'ideas' ? 'Sto cercando…' : 'Genera 5 idee →'}</button></form>
        {ideas.length > 0 && <div className="idea-grid">{ideas.map((idea) => <article key={idea.title}><span className="category-label">{idea.category}</span><h3>{idea.title}</h3><p>{idea.reader_question}</p><small>{idea.why_now}</small><button type="button" onClick={() => { setTopic(idea.title); setCategory(idea.category || category); document.querySelector('.studio-workspace')?.scrollIntoView({ behavior: 'smooth' }); }}>Usa questa idea →</button></article>)}</div>}
      </section>

      <section className="studio-workspace">
        <aside className="cycle-sidebar">
          <div><p className="eyebrow">Produzione</p><h2>Cicli editoriali</h2></div>
          <form className="studio-form" onSubmit={create}>
            <label>Argomento<input value={topic} onChange={(event) => setTopic(event.target.value)} placeholder="Es. Confini tra lavoro e famiglia" required /></label>
            <label>Categoria<select value={category} onChange={(event) => setCategory(event.target.value)}>{categories.map((item) => <option key={item}>{item}</option>)}</select></label>
            <button className="button button-wide" disabled={busy === 'create'}>{busy === 'create' ? 'Creo…' : 'Crea ciclo'}</button>
          </form>
          <div className="cycle-list">
            {cycles.map((cycle) => <button className={selected?.cycle.id === cycle.id ? 'active' : ''} onClick={() => loadCycle(cycle.id)} key={cycle.id} disabled={busy === `load-${cycle.id}`}><strong>{cycle.topic}</strong><span>{cycle.category} · {stateLabels[cycle.state]}</span></button>)}
            {!cycles.length && <p>Nessun ciclo: genera un’idea o inserisci il primo argomento.</p>}
          </div>
        </aside>

        <section className="cycle-detail">
          {!selected ? <div className="studio-empty"><span>✦</span><h2>La prossima uscita comincia qui.</h2><p>Scegli un tema oppure usa lo Scout per trovare cinque opportunità attuali.</p></div> : <>
            <header className="cycle-title"><div><span className="state-pill">{stateLabels[selected.cycle.state]}</span><h2>{selected.cycle.topic}</h2><p>{selected.cycle.category} · aggiornato {new Date(selected.cycle.updatedAt).toLocaleString('it-IT')}</p></div></header>
            <div className="workflow-strip">{agents.filter((agent) => agent.key !== 'topic_scout').map((agent) => <div className={completedKinds.has(kindFor(agent.key)) ? 'done' : selected.cycle.currentAgent === agent.key ? 'current' : ''} key={agent.key}><span>{completedKinds.has(kindFor(agent.key)) ? '✓' : '·'}</span><small>{agent.shortName}</small></div>)}</div>
            {(articleArtifact || podcastArtifact) && <section className="review-previews" aria-labelledby="review-previews-title">
              <div><p className="eyebrow">Prima di approvare</p><h3 id="review-previews-title">Leggi i contenuti finali.</h3><p>Le anteprime non pubblicano e non modificano nulla.</p></div>
              <div>
                {articleArtifact && <button type="button" onClick={() => setPreview('article')}><span>Articolo · {String(articleCounts.article || '—')} parole<br />Newsletter · {String(articleCounts.newsletter || '—')} parole</span><strong>Leggi l’articolo →</strong></button>}
                {podcastArtifact && <button type="button" onClick={() => setPreview('podcast')}><span>Podcast · {String(podcastCounts.podcast || '—')} parole</span><strong>Leggi la trascrizione →</strong></button>}
              </div>
            </section>}
            <div className="cycle-actions">
              {!['ready_for_approval', 'approved', 'published', 'archived'].includes(selected.cycle.state) && <button className="button" onClick={runNext} disabled={busy === 'run'}>{busy === 'run' ? 'L’agente sta lavorando…' : `Avvia ${agents.find((agent) => agent.key === selected.cycle.currentAgent)?.name || 'prossimo agente'} →`}</button>}
              {selected.cycle.state === 'ready_for_approval' && <div className="approval-box"><h3>Approvazione umana</h3><p>Scegli esattamente dove potrà operare il Publisher.</p><div>{(['site', 'newsletter', 'podcast_bundle'] as PublicationChannel[]).map((channel) => <label key={channel}><input type="checkbox" checked={channels.includes(channel)} onChange={(event) => setChannels((current) => event.target.checked ? [...current, channel] : current.filter((item) => item !== channel))} />{channel === 'site' ? 'Sito' : channel === 'newsletter' ? 'Newsletter' : 'Pacchetto Spotify/YouTube'}</label>)}</div><button className="button" onClick={approve} disabled={busy === 'approve'}>{busy === 'approve' ? 'Approvo…' : 'Approva questa versione'}</button></div>}
              {selected.cycle.state === 'approved' && <button className="button publish-button" onClick={publish} disabled={busy === 'publish'}>{busy === 'publish' ? 'Pubblicazione…' : 'Pubblica sui canali approvati →'}</button>}
              {selected.cycle.state === 'published' && <button className="button" onClick={runNext} disabled={busy === 'run'}>Esegui controllo post-pubblicazione</button>}
            </div>
            <div className="artifact-list">
              {[...selected.artifacts].reverse().map((artifact) => <details key={artifact.id}><summary><span>{artifact.kind.replaceAll('_', ' ')}</span><small>v{artifact.version} · {artifact.createdBy}</small></summary><div><p>{artifact.contentMarkdown}</p><pre>{JSON.stringify(artifact.content, null, 2)}</pre>{artifact.sources.length > 0 && <ul>{artifact.sources.map((source) => <li key={source.url}><a href={source.url} target="_blank" rel="noreferrer">{source.title}</a></li>)}</ul>}</div></details>)}
            </div>
          </>}
        </section>
      </section>

      <section className="studio-section market-section">
        <header><p className="eyebrow">Playbook 2026</p><h2>Progettato per il mercato di oggi.</h2></header>
        <div className="market-grid">{Object.entries(playbook).map(([key, item]) => <article key={key}><h3>{item.title}</h3><ul>{item.rules.map((rule) => <li key={rule}>{rule}</li>)}</ul><p>{item.sources.map((source, index) => <span key={source.url}><a href={source.url} target="_blank" rel="noreferrer">{source.label}</a>{index < item.sources.length - 1 ? ' · ' : ''}</span>)}</p></article>)}</div>
      </section>

      <section className="studio-section launch-checklist"><header><p className="eyebrow">Prima del lancio</p><h2>Connessioni esterne da completare.</h2></header><ol><li>Collegare la chiave del motore AI per sostituire la modalità dimostrativa.</li><li>Configurare dominio mittente, SPF, DKIM, DMARC e provider newsletter.</li><li>Aprire Spotify for Creators e YouTube Studio, verificare gli account e collegare il feed.</li><li>Registrare il primo episodio in video 16:9 e preparare almeno una clip verticale.</li><li>Pubblicare soltanto dopo l’approvazione nello Studio.</li></ol></section>
      {preview === 'article' && articleArtifact && <ArticlePreview artifact={articleArtifact} onClose={() => setPreview(null)} />}
      {preview === 'podcast' && podcastArtifact && <PodcastPreview artifact={podcastArtifact} onClose={() => setPreview(null)} />}
    </main>
  );
}

function Status({ label, value }: { label: string; value: string }) { return <div><span>{label}</span><strong>{value}</strong></div>; }
function kindFor(agent: AgentKey) { return ({ editor_in_chief: 'brief', researcher: 'research', article_writer: 'article', podcast_producer: 'podcast', reviewer: 'review', publisher: 'distribution', site_manager_analyst: 'quality_report', topic_scout: 'ideas' } as Record<AgentKey, string>)[agent]; }

function latestArtifact(pack: CyclePackage | null, kind: string) {
  return pack?.artifacts.filter((artifact) => artifact.kind === kind).sort((a, b) => b.version - a.version)[0] || null;
}

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function strings(value: unknown): string[] {
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === 'string' && item.trim().length > 0);
  return typeof value === 'string' && value.trim() ? [value] : [];
}

function PreviewFrame({ eyebrow, title, subtitle, onClose, children }: { eyebrow: string; title: string; subtitle?: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="preview-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <article className="editorial-preview" role="dialog" aria-modal="true" aria-labelledby="editorial-preview-title">
      <header><div><p className="eyebrow">{eyebrow}</p><h2 id="editorial-preview-title">{title}</h2>{subtitle && <p>{subtitle}</p>}</div><button type="button" onClick={onClose} aria-label="Chiudi anteprima">Chiudi ×</button></header>
      <div className="editorial-preview-body">{children}</div>
      <footer><button type="button" className="button" onClick={onClose}>Torna alla redazione</button><p>Questa è un’anteprima privata. Nessun contenuto è stato pubblicato.</p></footer>
    </article>
  </div>;
}

function ArticlePreview({ artifact, onClose }: { artifact: EditorialArtifact; onClose: () => void }) {
  const article = record(artifact.content.article || artifact.content);
  const counts = record(artifact.content.word_counts);
  const title = String(article.title || 'Anteprima articolo');
  const description = String(article.description || '');
  const body = strings(article.body);
  const sections = Array.isArray(article.sections) ? article.sections.map(record) : [];
  return <PreviewFrame eyebrow={`Articolo · versione ${artifact.version}`} title={title} subtitle={[description, counts.article ? `${counts.article} parole` : ''].filter(Boolean).join(' · ')} onClose={onClose}>
    {body.length > 0 ? body.map((paragraph, index) => <p key={`${index}-${paragraph.slice(0, 20)}`}>{paragraph}</p>) : <p className="preview-fallback">{artifact.contentMarkdown}</p>}
    {sections.map((section, index) => <section key={`${index}-${String(section.title || '')}`}><h3>{String(section.title || '')}</h3>{strings(section.paragraphs).map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</section>)}
    {artifact.sources.length > 0 && <aside><h3>Fonti consultate</h3><ul>{artifact.sources.map((source) => <li key={source.url}><a href={source.url} target="_blank" rel="noreferrer">{source.title}</a></li>)}</ul></aside>}
  </PreviewFrame>;
}

function PodcastPreview({ artifact, onClose }: { artifact: EditorialArtifact; onClose: () => void }) {
  const podcast = record(artifact.content);
  const counts = record(artifact.content.word_counts);
  const title = String(podcast.title || 'Anteprima podcast');
  const transcript = strings(podcast.transcript);
  const scriptSections = Array.isArray(podcast.script_sections) ? podcast.script_sections.map(record) : [];
  const spokenText = scriptSections.flatMap((section) => strings(section.spoken_text));
  const paragraphs = transcript.length > 0 ? transcript : spokenText;
  return <PreviewFrame eyebrow={`Trascrizione podcast · versione ${artifact.version}`} title={title} subtitle={[podcast.number, podcast.duration, counts.podcast ? `${counts.podcast} parole` : ''].filter(Boolean).join(' · ')} onClose={onClose}>
    {Boolean(podcast.opening_hook) && <blockquote><span>Apertura</span>{String(podcast.opening_hook)}</blockquote>}
    <section><h3>{transcript.length > 0 ? 'Trascrizione completa' : 'Testo da registrare'}</h3>{paragraphs.length > 0 ? paragraphs.map((paragraph, index) => <p key={`${index}-${paragraph.slice(0, 20)}`}>{paragraph}</p>) : <p className="preview-fallback">{artifact.contentMarkdown}</p>}</section>
    {scriptSections.length > 0 && <aside><h3>Scaletta del copione</h3>{scriptSections.map((section, index) => <div key={`${index}-${String(section.title || '')}`}><strong>{String(section.title || `Parte ${index + 1}`)}</strong><p>{String(section.spoken_text || '')}</p></div>)}</aside>}
  </PreviewFrame>;
}
