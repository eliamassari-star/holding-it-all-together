'use client';

import { FormEvent, useEffect, useState } from 'react';

type Props = { children: React.ReactNode; className?: string };

export function SubscribeButton({ children, className = 'button' }: Props) {
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => event.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKeyDown);
    document.body.classList.add('modal-open');
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.classList.remove('modal-open');
    };
  }, [open]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus('loading');
    setMessage('');
    const data = Object.fromEntries(new FormData(event.currentTarget));
    try {
      const response = await fetch('/api/subscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      const result = await response.json() as { message?: string };
      if (!response.ok) throw new Error(result.message || 'Qualcosa non ha funzionato.');
      setStatus('success');
      setMessage(result.message || 'Controlla la tua email per confermare l’iscrizione.');
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Riprova tra poco.');
    }
  }

  return (
    <>
      <button className={className} type="button" onClick={() => { setOpen(true); setStatus('idle'); }}>
        {children}<span aria-hidden="true">→</span>
      </button>
      {open && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.currentTarget === event.target && setOpen(false)}>
          <section className="subscribe-modal" role="dialog" aria-modal="true" aria-labelledby="subscribe-title">
            <button className="modal-close" type="button" onClick={() => setOpen(false)} aria-label="Chiudi">×</button>
            {status === 'success' ? (
              <div className="form-success" role="status">
                <span>✓</span><p className="eyebrow">Quasi fatto</p><h2 id="subscribe-title">Controlla la tua casella.</h2><p>{message}</p>
                <button className="button" type="button" onClick={() => setOpen(false)}>Continua a leggere</button>
              </div>
            ) : (
              <>
                <p className="eyebrow">La newsletter del giovedì</p>
                <h2 id="subscribe-title">Una vita più serena è possibile.</h2>
                <p>Una lettera breve, concreta e umana per affrontare lavoro, soldi, famiglia e tutto il resto.</p>
                <form className="subscribe-form" onSubmit={submit}>
                  <label>Nome <span>(opzionale)</span><input name="name" type="text" autoComplete="given-name" /></label>
                  <label>Email<input name="email" type="email" autoComplete="email" required placeholder="tu@esempio.it" /></label>
                  <label className="honeypot" aria-hidden="true">Sito web<input name="website" type="text" tabIndex={-1} autoComplete="off" /></label>
                  <label className="privacy-check"><input name="privacy" type="checkbox" value="accepted" required /><span>Ho letto la <a href="/privacy" target="_blank">privacy policy</a> e acconsento al trattamento dei dati.</span></label>
                  <label className="privacy-check"><input name="tracking" type="checkbox" value="accepted" /><span>Acconsento separatamente alla misurazione individuale di aperture e interazioni. Posso revocarla senza interrompere la newsletter.</span></label>
                  <button className="button button-wide" type="submit" disabled={status === 'loading'}>
                    {status === 'loading' ? <><span className="spinner" /> Iscrizione in corso</> : <>Iscriviti gratuitamente <span aria-hidden="true">→</span></>}
                  </button>
                  {status === 'error' && <p className="form-error" role="alert">{message}</p>}
                  <small>Una lettera ogni giovedì. Riceverai un’email per confermare l’iscrizione e potrai disiscriverti con un clic.</small>
                </form>
              </>
            )}
          </section>
        </div>
      )}
    </>
  );
}
