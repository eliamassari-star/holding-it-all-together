export const siteConfig = {
  name: 'Holding It All Together',
  tagline: 'Work. Money. Family. Life.',
  description: 'Lavoro, conti, famiglia e vita reale: storie, scelte e strumenti per affrontare giornate che non sono mai perfette.',
  url: process.env.NEXT_PUBLIC_SITE_URL || 'https://holding-it-all-together.elia-massari.chatgpt.site',
  socials: {
    instagram: process.env.NEXT_PUBLIC_INSTAGRAM_URL || 'https://www.instagram.com/',
    linkedin: process.env.NEXT_PUBLIC_LINKEDIN_URL || 'https://www.linkedin.com/',
    youtube: process.env.NEXT_PUBLIC_YOUTUBE_URL || 'https://www.youtube.com/',
    spotify: process.env.NEXT_PUBLIC_SPOTIFY_URL || 'https://open.spotify.com/search/Holding%20It%20All%20Together',
    apple: process.env.NEXT_PUBLIC_APPLE_PODCASTS_URL || 'https://podcasts.apple.com/us/search?term=Holding%20It%20All%20Together',
  },
  podcastRss: process.env.NEXT_PUBLIC_PODCAST_RSS_URL || '/podcast/rss.xml',
};
