export type Article = {
  slug: string;
  category: string;
  title: string;
  description: string;
  readingTime: string;
  date: string;
  image: string;
  imagePosition?: string;
  body: string[];
};

export type NewsletterIssue = {
  slug: string;
  number: string;
  date: string;
  title: string;
  subtitle: string;
  introduction: string;
  heroImage: string;
  author: string;
  seoTitle: string;
  seoDescription: string;
  sections: { title: string; paragraphs: string[] }[];
  linkedArticles: string[];
};

export type PodcastEpisode = {
  slug: string;
  number: string;
  title: string;
  date: string;
  duration: string;
  description: string;
  image: string;
  showNotes: string[];
  chapters: { time: string; title: string }[];
  links: { label: string; url: string }[];
  transcript: string[];
  audioUrl?: string;
};

export const articles: Article[] = [
  {
    slug: 'budget-famiglia-che-funziona',
    category: 'Soldi',
    title: 'Un budget di famiglia che funziona davvero',
    description: 'Più consapevolezza. Meno stress. Più libertà.',
    readingTime: '5 min di lettura',
    date: '10 Dic 2024',
    image: '/images/podcast-hero.png',
    imagePosition: 'center 72%',
    body: [
      'Un budget utile non è una gabbia: è un modo semplice per decidere insieme che cosa conta davvero.',
      'Partite dalle spese che rendono più serena la vita quotidiana, poi costruite tre piccole categorie: necessario, importante e desiderato. Non serve inseguire ogni centesimo.',
      'Una revisione di venti minuti alla settimana è spesso più efficace di un foglio perfetto abbandonato dopo un mese. La costanza deve essere leggera per durare.',
    ],
  },
  {
    slug: 'mattine-impegnative',
    category: 'Famiglia',
    title: 'Come affrontare le mattine impegnative',
    description: 'Piccole strategie per grandi giornate.',
    readingTime: '5 min di lettura',
    date: '8 Dic 2024',
    image: '/images/home-hero.png',
    imagePosition: '68% center',
    body: [
      'Le mattine cambiano quando togliamo decisioni inutili dal momento più fragile della giornata.',
      'Preparare una sola cosa la sera prima — vestiti, zaini o colazione — crea spazio mentale per tutto il resto. Scegliete quella che oggi genera più attrito.',
      'Lasciate anche un piccolo margine non programmato. Dieci minuti di respiro valgono più di una routine troppo precisa.',
    ],
  },
  {
    slug: 'proteggi-il-tuo-tempo',
    category: 'Lavoro',
    title: 'Proteggi il tuo tempo (anche a casa)',
    description: 'Meno distrazioni, più cose che contano.',
    readingTime: '7 min di lettura',
    date: '5 Dic 2024',
    image: '/images/newsletter-hero.png',
    imagePosition: '25% center',
    body: [
      'Il tempo protetto non è tempo isolato: è tempo a cui abbiamo dato un’intenzione chiara.',
      'Create blocchi brevi e visibili, comunicateli alle persone con cui vivete e chiudeteli con un gesto concreto. Anche riporre il computer può diventare un confine.',
      'La produttività sostenibile non riempie ogni spazio. Conserva energia per tornare presenti quando il lavoro finisce.',
    ],
  },
  {
    slug: 'abitudini-finanziarie',
    category: 'Soldi',
    title: '5 piccole abitudini finanziarie che fanno una grande differenza',
    description: 'Azioni minime per costruire più tranquillità nel tempo.',
    readingTime: '6 min di lettura',
    date: '2 Dic 2024',
    image: '/images/newsletter-hero.png',
    body: ['Automatizzare una piccola somma, controllare gli abbonamenti e parlare di denaro senza giudizio sono gesti semplici che cambiano il clima familiare.'],
  },
  {
    slug: 'giornate-piene-senza-perdere-la-calma',
    category: 'Famiglia',
    title: 'Come gestire le giornate piene senza perdere la calma',
    description: 'Ridurre gli attriti e scegliere un ritmo più umano.',
    readingTime: '6 min di lettura',
    date: '28 Nov 2024',
    image: '/images/home-hero.png',
    body: ['Quando tutto sembra urgente, decidere insieme che cosa può aspettare è già una forma di cura.'],
  },
  {
    slug: 'strumenti-risparmiare-tempo',
    category: 'Organizzazione',
    title: '3 strumenti utili per risparmiare tempo questa settimana',
    description: 'Una lista breve, concreta e subito applicabile.',
    readingTime: '4 min di lettura',
    date: '24 Nov 2024',
    image: '/images/newsletter-cta.png',
    body: ['Un calendario condiviso, una lista ricorrente e un’unica raccolta per le cose da ricordare: tre strumenti sono più che sufficienti.'],
  },
];

export const newsletterIssues: NewsletterIssue[] = [
  {
    slug: 'piccoli-passi-vita-piu-gestibile',
    number: '#012',
    date: '12 Dic 2024',
    title: 'Piccoli passi.\nUna vita più gestibile.',
    subtitle: 'Il numero dedicato alle abitudini che liberano spazio.',
    introduction: 'Idee pratiche, storie vere e strumenti utili per affrontare il quotidiano — al lavoro, a casa e in tutto ciò che sta nel mezzo.',
    heroImage: '/images/newsletter-hero.png',
    author: 'Redazione Holding It All Together',
    seoTitle: 'Piccoli passi. Una vita più gestibile. — Newsletter #012',
    seoDescription: 'Quattro idee concrete per rendere più leggere le giornate piene.',
    linkedArticles: ['abitudini-finanziarie', 'giornate-piene-senza-perdere-la-calma', 'proteggi-il-tuo-tempo', 'strumenti-risparmiare-tempo'],
    sections: [
      { title: 'Partire da ciò che è piccolo', paragraphs: ['Non serve rivoluzionare l’intera settimana. Basta osservare dove perdiamo energia e scegliere un gesto capace di alleggerire proprio quel punto.', 'In questo numero raccogliamo quattro idee che possono entrare nella vita così com’è, senza chiedere più disciplina di quanta ne abbiamo già.'] },
      { title: 'Una domanda per la settimana', paragraphs: ['Qual è la decisione che continui a prendere ogni giorno e che potresti prendere una volta sola?'] },
    ],
  },
  {
    slug: 'spazio-alle-cose-che-contano',
    number: '#011',
    date: '5 Dic 2024',
    title: 'Più spazio.\nPer le cose che contano.',
    subtitle: 'Confini gentili tra lavoro e casa.',
    introduction: 'Un numero dedicato a tempo, presenza e scelte abbastanza buone.',
    heroImage: '/images/newsletter-cta.png',
    author: 'Redazione Holding It All Together',
    seoTitle: 'Più spazio per le cose che contano — Newsletter #011',
    seoDescription: 'Come proteggere tempo ed energia senza irrigidire la giornata.',
    linkedArticles: ['proteggi-il-tuo-tempo', 'mattine-impegnative'],
    sections: [{ title: 'Confini visibili', paragraphs: ['Un confine funziona quando è comprensibile anche per chi vive e lavora con noi.'] }],
  },
  {
    slug: 'denaro-senza-ansia',
    number: '#010',
    date: '28 Nov 2024',
    title: 'Parlare di soldi.\nSenza perdere serenità.',
    subtitle: 'Un lessico più semplice per le decisioni di famiglia.',
    introduction: 'Strumenti e parole concrete per rendere il denaro un tema condiviso.',
    heroImage: '/images/newsletter-hero.png',
    author: 'Redazione Holding It All Together',
    seoTitle: 'Denaro senza ansia — Newsletter #010',
    seoDescription: 'Idee concrete per parlare di soldi in famiglia.',
    linkedArticles: ['budget-famiglia-che-funziona', 'abitudini-finanziarie'],
    sections: [{ title: 'Cominciare senza giudizio', paragraphs: ['I numeri diventano più gestibili quando smettono di essere una misura del nostro valore.'] }],
  },
];

export const podcastEpisodes: PodcastEpisode[] = [
  {
    slug: 'il-tempo-che-protegge-la-vita',
    number: 'EP. 12',
    title: 'Il tempo che protegge la vita',
    date: '12 Dic 2024',
    duration: '34 min',
    description: 'Come costruire confini reali tra lavoro, famiglia e il tempo che vogliamo custodire.',
    image: '/images/podcast-hero.png',
    showNotes: ['Perché i confini devono essere visibili', 'Il ruolo delle micro-routine', 'Come chiudere davvero la giornata di lavoro'],
    chapters: [{ time: '00:00', title: 'Introduzione' }, { time: '06:40', title: 'Confini che funzionano' }, { time: '18:20', title: 'Il rituale di chiusura' }, { time: '29:10', title: 'Una pratica per questa settimana' }],
    links: [{ label: 'Articolo: Proteggi il tuo tempo', url: '/articoli/proteggi-il-tuo-tempo' }],
    transcript: ['Ci sono giornate in cui il lavoro non finisce: semplicemente cambia stanza.', 'In questo episodio cerchiamo un modo più umano per segnare il passaggio e tornare presenti.'],
  },
  {
    slug: 'soldi-conversazioni-possibili',
    number: 'EP. 11',
    title: 'Soldi: conversazioni possibili',
    date: '5 Dic 2024',
    duration: '29 min',
    description: 'Parlare di denaro senza trasformare ogni scelta in un conflitto.',
    image: '/images/newsletter-hero.png',
    showNotes: ['Partire dai valori', 'Fare spazio alle emozioni', 'Una riunione familiare di venti minuti'],
    chapters: [{ time: '00:00', title: 'Da dove partiamo' }, { time: '10:15', title: 'Valori prima dei numeri' }, { time: '22:00', title: 'Una pratica concreta' }],
    links: [{ label: 'Articolo: Un budget di famiglia', url: '/articoli/budget-famiglia-che-funziona' }],
    transcript: ['Il denaro è fatto di numeri, ma le conversazioni sul denaro sono fatte soprattutto di emozioni.'],
  },
  {
    slug: 'mattine-non-perfette',
    number: 'EP. 10',
    title: 'Mattine non perfette',
    date: '28 Nov 2024',
    duration: '26 min',
    description: 'Strategie leggere per iniziare la giornata senza rincorrere la perfezione.',
    image: '/images/home-hero.png',
    showNotes: ['Togliere una decisione', 'Costruire un margine', 'Ripartire dopo una mattina difficile'],
    chapters: [{ time: '00:00', title: 'Una mattina vera' }, { time: '08:30', title: 'Meno decisioni' }, { time: '19:10', title: 'Il margine' }],
    links: [{ label: 'Articolo: Mattine impegnative', url: '/articoli/mattine-impegnative' }],
    transcript: ['Una mattina riuscita non è una mattina perfetta. È una mattina che lascia ancora energia per il resto della giornata.'],
  },
];

export const categories = [
  { slug: 'lavoro', title: 'Lavoro', description: 'Produttività\nsenza stress' },
  { slug: 'soldi', title: 'Soldi', description: 'Budget, risparmio,\ninvestimenti reali' },
  { slug: 'famiglia', title: 'Famiglia', description: 'Relazioni, bambini,\nvita di coppia' },
  { slug: 'benessere', title: 'Benessere', description: 'Salute, equilibrio,\nmente serena' },
  { slug: 'organizzazione', title: 'Organizzazione', description: 'Tempo, abitudini,\nvita quotidiana' },
];

export function getArticle(slug: string) { return articles.find((item) => item.slug === slug); }
export function getIssue(slug: string) { return newsletterIssues.find((item) => item.slug === slug); }
export function getEpisode(slug: string) { return podcastEpisodes.find((item) => item.slug === slug); }
