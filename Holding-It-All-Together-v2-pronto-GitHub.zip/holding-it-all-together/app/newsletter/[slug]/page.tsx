import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';
import { SubscribeButton } from '../../components/SubscribeButton';
import { newsletterIssues } from '../../data/content';
import { getArticles, getNewsletterIssue } from '../../../lib/editorial/public-content';

export function generateStaticParams() {
  return newsletterIssues.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const issue = await getNewsletterIssue(slug);
  if (!issue) return {};
  return {
    title: issue.seoTitle,
    description: issue.seoDescription,
    alternates: { canonical: `/newsletter/${slug}` },
    openGraph: { title: issue.seoTitle, description: issue.seoDescription, images: [issue.heroImage] },
    twitter: { card: 'summary_large_image', title: issue.seoTitle, description: issue.seoDescription, images: [issue.heroImage] },
  };
}

export default async function IssuePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const issue = await getNewsletterIssue(slug);
  if (!issue) notFound();
  const articles = await getArticles();
  const linked = issue.linkedArticles.map((id) => articles.find((article) => article.slug === id)).filter(Boolean);

  return (
    <>
      <Header />
      <main className="issue-page">
        <Link className="back-link" href="/newsletter/archive"><span aria-hidden="true">←</span> Archivio</Link>
        <header>
          <span>{issue.number}</span><time>{issue.date}</time>
          <h1>{issue.title.split('\n').map((line) => <span key={line}>{line}</span>)}</h1>
          <p>{issue.introduction}</p>
        </header>
        <img className="issue-hero" src={issue.heroImage} alt="" />
        <article className="prose">
          {issue.sections.map((section) => <section key={section.title}><h2>{section.title}</h2>{section.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</section>)}
          <hr />
          <h2>In questo numero</h2>
          <div className="issue-article-links">
            {linked.map((article) => article && <Link href={`/articoli/${article.slug}`} key={article.slug}><span className="category-label">{article.category}</span><strong>{article.title}</strong><span aria-hidden="true">→</span></Link>)}
          </div>
          <div className="inline-subscribe">
            <p className="eyebrow">La prossima lettera</p><h2>Arriva giovedì.</h2><p>Una lettura breve, senza rumore.</p>
            <SubscribeButton>Iscriviti gratuitamente</SubscribeButton>
          </div>
          <p className="byline">A cura di {issue.author}</p>
        </article>
      </main>
      <Footer />
    </>
  );
}
