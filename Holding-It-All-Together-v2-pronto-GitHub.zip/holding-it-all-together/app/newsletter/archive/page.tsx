import type { Metadata } from 'next';
import Link from 'next/link';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';
import { getNewsletterIssues } from '../../../lib/editorial/public-content';

export const metadata: Metadata = {
  title: 'Archivio newsletter',
  description: 'Tutti i numeri di Holding It All Together, dal più recente.',
  alternates: { canonical: '/newsletter/archive' },
};

export const dynamic = 'force-dynamic';

export default async function NewsletterArchivePage() {
  const newsletterIssues = await getNewsletterIssues();
  return (
    <>
      <Header />
      <main className="archive-page narrow-archive">
        <p className="eyebrow">Tutte le lettere</p>
        <h1>Archivio newsletter</h1>
        <p className="page-lede">Un’idea alla volta, dal numero più recente al primo.</p>
        <div className="issue-list">
          {newsletterIssues.map((issue) => (
            <Link href={`/newsletter/${issue.slug}`} key={issue.slug}>
              <span><strong>{issue.number}</strong><time>{issue.date}</time></span>
              <div><h2>{issue.title.replace('\n', ' ')}</h2><p>{issue.seoDescription}</p></div>
              <span aria-hidden="true">→</span>
            </Link>
          ))}
        </div>
      </main>
      <Footer />
    </>
  );
}
