import Link from 'next/link';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';

export default function ConfirmationPage() {
  return (
    <>
      <Header />
      <main className="status-page">
        <span aria-hidden="true">✓</span>
        <p className="eyebrow">Iscrizione confermata</p>
        <h1>Benvenuto nella community.</h1>
        <p>La prossima lettera arriverà giovedì. Nel frattempo puoi partire dagli articoli più letti.</p>
        <Link className="button" href="/articoli">Vai agli articoli</Link>
      </main>
      <Footer />
    </>
  );
}

