import type { Metadata } from 'next';
import Link from 'next/link';
import { Footer } from '../components/Footer';
import { Header } from '../components/Header';
import { NewsletterPanel } from '../components/NewsletterPanel';
import { getNewsletterIssues } from '../../lib/editorial/public-content';

export const metadata: Metadata = { title: 'Newsletter', description: 'La newsletter di Holding It All Together: idee concrete per una vita più gestibile.', alternates: { canonical: '/newsletter' } };

export const dynamic = 'force-dynamic';

export default async function NewsletterPage() {
  const newsletterIssues = await getNewsletterIssues();
  return <><Header /><main className="newsletter-page"><NewsletterPanel issue={newsletterIssues[0]} /><Link className="archive-link" href="/newsletter/archive">Sfoglia l’archivio completo →</Link></main><Footer /></>;
}
