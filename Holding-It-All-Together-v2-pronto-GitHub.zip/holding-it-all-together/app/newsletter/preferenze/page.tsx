import { AccountActionForm } from '../../components/AccountActionForm';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';
export default function PreferencesPage() { return <><Header /><main className="status-page account-page"><p className="eyebrow">Newsletter</p><h1>Gestisci preferenze</h1><p>Scegli quali aggiornamenti ricevere.</p><AccountActionForm action="preferences" /></main><Footer /></>; }
