import { AccountActionForm } from '../../components/AccountActionForm';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';
export default function UnsubscribePage() { return <><Header /><main className="status-page account-page"><p className="eyebrow">Newsletter</p><h1>Disiscriviti</h1><p>Ci dispiace vederti andare. Inserisci l’email da rimuovere.</p><AccountActionForm action="unsubscribe" /></main><Footer /></>; }
