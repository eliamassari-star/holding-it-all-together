import Link from 'next/link';
import { ArticleCard } from './components/ArticleCard';
import { CategoryNav } from './components/CategoryNav';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { SubscribeButton } from './components/SubscribeButton';
import { siteConfig } from './config';
import { getArticles } from '../lib/editorial/public-content';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const articles = await getArticles();
  const organization = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: siteConfig.name,
    url: siteConfig.url,
    description: siteConfig.description,
  };

  return (
    <>
      <Header />
      <main id="contenuto">
        <section className="hero">
          <img src="/images/home-hero.png" alt="Una famiglia riunita davanti a una valle al tramonto" fetchPriority="high" />
          <div className="hero-copy">
            <p className="hero-kicker">WORK · MONEY · FAMILY · LIFE</p>
            <h1>La vita non è perfetta.<br />Ma è la nostra.</h1>
            <p>Il lavoro che ci porta lontano. I figli che crescono. I conti da far tornare. E la voglia di esserci davvero. Qui raccontiamo tutto, senza filtri e senza vendere la vita perfetta.</p>
            <div className="hero-ctas">
              <Link className="button" href="/chi-siamo">Scopri la nostra storia</Link>
              <Link className="hero-secondary" href="/articoli">Leggi le storie <span aria-hidden="true">→</span></Link>
            </div>
          </div>
        </section>

        <section className="manifesto section-shell" aria-labelledby="manifesto-heading">
          <div><p className="eyebrow">IL NOSTRO PUNTO DI PARTENZA</p><h2 id="manifesto-heading">Tenere insieme tutto non significa non cadere mai.</h2></div>
          <div><p>Significa provare a esserci, anche quando il tempo non basta. Parlare di lavoro senza fingere che non pesi. Parlare di soldi senza vergogna. Parlare di famiglia senza idealizzarla.</p><Link href="/chi-siamo">Perché nasce questo progetto <span aria-hidden="true">→</span></Link></div>
        </section>

        <CategoryNav />

        <section className="featured section-shell">
          <header className="section-heading">
            <h2>Storie, idee e strumenti</h2>
            <Link href="/articoli">Vedi tutti gli articoli <span aria-hidden="true">→</span></Link>
          </header>
          {articles.length > 0 ? <div className="article-grid">{articles.slice(0, 3).map((article) => <ArticleCard article={article} key={article.slug} />)}</div> : <p>Le prime storie arriveranno qui.</p>}
        </section>

        <section className="story-invitation section-shell" aria-labelledby="story-heading">
          <div><p className="eyebrow">UN RACCONTO CHE CONTINUA</p><h2 id="story-heading">Non un'altra storia di successo. Una storia di vita.</h2></div>
          <div><p>Giornate difficili, decisioni, errori, piccoli progressi. Video, articoli e conversazioni che ripartono sempre da una domanda: come possiamo vivere meglio la vita che abbiamo, invece di inseguirne una finta?</p><Link className="button" href="/podcast">Segui gli episodi</Link></div>
        </section>

        <section className="newsletter-banner">
          <img src="/images/newsletter-cta.png" alt="Un adulto e un bambino seduti insieme su un pontile al tramonto" loading="lazy" />
          <div>
            <p className="script-copy">Non devi avere<br />tutto sotto controllo.</p>
            <p>Possiamo raccontarla insieme.</p>
            <SubscribeButton className="button button-light">Iscriviti gratuitamente</SubscribeButton>
          </div>
        </section>
      </main>
      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organization) }} />
    </>
  );
}
