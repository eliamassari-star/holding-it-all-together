import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Footer } from '../../components/Footer';
import { Header } from '../../components/Header';
import { PodcastLinks } from '../../components/PodcastLinks';
import { siteConfig } from '../../config';
import { podcastEpisodes } from '../../data/content';
import { getPodcastEpisode, getPodcastEpisodes } from '../../../lib/editorial/public-content';

export function generateStaticParams() {
  return podcastEpisodes.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const episode = await getPodcastEpisode(slug);
  if (!episode) return {};
  return {
    title: episode.title,
    description: episode.description,
    alternates: { canonical: `/podcast/${slug}` },
    openGraph: { title: episode.title, description: episode.description, images: [episode.image] },
    twitter: { card: 'summary_large_image', title: episode.title, description: episode.description, images: [episode.image] },
  };
}

export default async function EpisodePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const episode = await getPodcastEpisode(slug);
  if (!episode) notFound();
  const allEpisodes = await getPodcastEpisodes();
  const related = allEpisodes.filter((item) => item.slug !== slug).slice(0, 2);
  const structured = { '@context': 'https://schema.org', '@type': 'PodcastEpisode', name: episode.title, description: episode.description, duration: episode.duration, datePublished: '2024-12-12', partOfSeries: { '@type': 'PodcastSeries', name: siteConfig.name } };

  return (
    <>
      <Header />
      <main className="episode-page">
        <Link className="back-link" href="/podcast"><span aria-hidden="true">←</span> Tutti gli episodi</Link>
        <header>
          <div><span className="category-label">{episode.number}</span><h1>{episode.title}</h1><p>{episode.description}</p><small>{episode.date} · {episode.duration}</small></div>
          <img src={episode.image} alt="" />
        </header>
        <section className="episode-player">
          <p className="eyebrow">Ascolta ora</p>
          {episode.audioUrl ? <audio controls preload="metadata" src={episode.audioUrl}>Il tuo browser non supporta il player audio.</audio> : <><h2>Scegli la tua piattaforma.</h2><PodcastLinks labels /></>}
        </section>
        <article className="prose">
          <h2>Show notes</h2><ul>{episode.showNotes.map((note) => <li key={note}>{note}</li>)}</ul>
          <h2>Capitoli</h2><ol className="chapters">{episode.chapters.map((chapter) => <li key={chapter.time}><time>{chapter.time}</time><span>{chapter.title}</span></li>)}</ol>
          <h2>Link citati</h2><ul>{episode.links.map((link) => <li key={link.url}><Link href={link.url}>{link.label}</Link></li>)}</ul>
          <h2>Trascrizione</h2>{episode.transcript.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
        </article>
        <section className="related-episodes"><h2>Episodi correlati</h2>{related.map((item) => <Link href={`/podcast/${item.slug}`} key={item.slug}><span>{item.number}</span><strong>{item.title}</strong></Link>)}</section>
      </main>
      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structured) }} />
    </>
  );
}
