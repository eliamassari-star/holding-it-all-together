import { getPodcastEpisode } from '@/lib/editorial/public-content';

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const episode = await getPodcastEpisode((await params).slug);
  if (!episode) return new Response('Not found', { status: 404 });
  const cues = episode.transcript.map((paragraph, index) => {
    const start = index * 20;
    const end = start + 20;
    return `${index + 1}\n${time(start)} --> ${time(end)}\n${paragraph}\n`;
  }).join('\n');
  return new Response(`WEBVTT\n\n${cues}`, { headers: { 'Content-Type': 'text/vtt; charset=utf-8' } });
}

function time(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
  const minutes = Math.floor(totalSeconds % 3600 / 60).toString().padStart(2, '0');
  const seconds = (totalSeconds % 60).toString().padStart(2, '0');
  return `${hours}:${minutes}:${seconds}.000`;
}
