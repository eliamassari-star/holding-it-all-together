import type { Metadata } from 'next';
import Link from 'next/link';
import { Brand } from '../components/Brand';
import { Footer } from '../components/Footer';
import { Header } from '../components/Header';
import { PodcastLinks } from '../components/PodcastLinks';
import { siteConfig } from '../config';
import { getPodcastEpisodes } from '../../lib/editorial/public-content';

export const metadata: Metadata = {
  title: 'Podcast',
  description: 'Conversazioni vere per vite reali.',
  alternates: { canonical: '/podcast' },
  openGraph: { title: 'Conversazioni vere per vite reali.', description: 'Il podcast di Holding It All Together.', images: ['/images/podcast-hero.png'] },
};

export const dynamic = 'force-dynamic';

export default async function PodcastPage() {
  const podcastEpisodes = await getPodcastEpisodes();
  const structured = { '@context': 'https://schema.org', '@type': 'PodcastSeries', name: siteConfig.name, description: 'Conversazioni vere per vite reali.', webFeed: `${siteConfig.url}${siteConfig.podcastRss}` };
  return (
    <>
      <Header />
      <main className="podcast-page">
        <section className="podcast-hero">
          <img src="/images/podcast-hero.png" alt="Un adulto e una bambina sul divano davanti alla luce del tramonto" fetchPriority="high" />
          <div className="podcast-shade" />
          <div className="podcast-hero-copy">
            <Brand light />
            <span className="orange-rule" />
            <h1>Conversazioni<br />vere per<br /><em>vite reali.</em></h1>
            <p>Storie, idee e spunti pratici<br />per affrontare il lavoro,<br />i soldi, la famiglia<br />e tutto il resto.</p>
          </div>
          <div className="podcast-book-titles" aria-hidden="true"><span>Lavoro più consapevole</span><span>Famiglie più unite</span><span>Vite più piene</span></div>
          <div className="podcast-platforms"><p>UN PODCAST<br />COME TE.</p><PodcastLinks /></div>
        </section>
        <section className="episodes section-shell">
          <header className="section-heading"><div><p className="eyebrow">Ascolta quando vuoi</p><h2>Ultimi episodi</h2></div><a href={siteConfig.podcastRss}><span aria-hidden="true">◉</span> Feed RSS</a></header>
          <div className="episode-list">
            {podcastEpisodes.map((episode) => (
              <article className="episode-card" key={episode.slug}>
                <img src={episode.image} alt="" loading="lazy" />
                <div>
                  <span className="category-label">{episode.number}</span><h3>{episode.title}</h3><p>{episode.description}</p><small>{episode.date} · {episode.duration}</small>
                  <Link href={`/podcast/${episode.slug}`}>Ascolta l’episodio <span aria-hidden="true">→</span></Link>
                  <PodcastLinks labels />
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>
      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structured) }} />
    </>
  );
}
