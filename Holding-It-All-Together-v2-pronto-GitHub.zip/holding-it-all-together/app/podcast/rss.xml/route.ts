import { siteConfig } from '../../config';
import { getPodcastEpisodes } from '../../../lib/editorial/public-content';

export async function GET() {
  const podcastEpisodes = await getPodcastEpisodes();
  const items = podcastEpisodes.map((episode) => {
    const pageUrl = `${siteConfig.url}/podcast/${episode.slug}`;
    const audioUrl = episode.audioUrl ? new URL(episode.audioUrl, siteConfig.url).toString() : '';
    return `<item>
      <title><![CDATA[${episode.title}]]></title>
      <link>${pageUrl}</link>
      <guid isPermaLink="true">${pageUrl}</guid>
      <description><![CDATA[${episode.description}]]></description>
      <pubDate>${toRssDate(episode.date)}</pubDate>
      <itunes:episodeType>full</itunes:episodeType>
      <itunes:duration>${escapeXml(episode.duration)}</itunes:duration>
      <itunes:image href="${new URL(episode.image, siteConfig.url)}" />
      <podcast:transcript url="${siteConfig.url}/podcast/${episode.slug}/transcript.vtt" type="text/vtt" />
      ${audioUrl ? `<enclosure url="${escapeXml(audioUrl)}" length="0" type="audio/mpeg" />` : ''}
    </item>`;
  }).join('');
  const owner = process.env.PODCAST_OWNER_EMAIL ? `<itunes:owner><itunes:name>${siteConfig.name}</itunes:name><itunes:email>${escapeXml(process.env.PODCAST_OWNER_EMAIL)}</itunes:email></itunes:owner>` : '';
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
  <rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd" xmlns:podcast="https://podcastindex.org/namespace/1.0">
    <channel>
      <title>${siteConfig.name}</title>
      <link>${siteConfig.url}/podcast</link>
      <atom:link href="${siteConfig.url}/podcast/rss.xml" rel="self" type="application/rss+xml" />
      <language>it-IT</language>
      <description>Conversazioni vere per vite reali.</description>
      <itunes:author>${siteConfig.name}</itunes:author>
      <itunes:explicit>false</itunes:explicit>
      <itunes:type>episodic</itunes:type>
      <itunes:image href="${siteConfig.url}/images/podcast-hero.png" />
      <itunes:category text="Society &amp; Culture" />
      ${owner}
      ${items}
    </channel>
  </rss>`;
  return new Response(xml, { headers: { 'Content-Type': 'application/rss+xml; charset=utf-8' } });
}

function escapeXml(value: string) { return value.replace(/[<>&"']/g, (character) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[character] || character); }
function toRssDate(value: string) {
  const italianMonths: Record<string, number> = {
    gen: 0, feb: 1, mar: 2, apr: 3, mag: 4, giu: 5,
    lug: 6, ago: 7, set: 8, ott: 9, nov: 10, dic: 11,
  };
  const italianDate = value.trim().match(/^(\d{1,2})\s+([a-z]{3})\s+(\d{4})$/i);
  if (italianDate) {
    const month = italianMonths[italianDate[2].toLowerCase()];
    if (month !== undefined) return new Date(Date.UTC(Number(italianDate[3]), month, Number(italianDate[1]), 9)).toUTCString();
  }
  const parsed = Date.parse(value);
  return new Date(Number.isNaN(parsed) ? Date.now() : parsed).toUTCString();
}
