import type { Metadata } from 'next';
import Link from 'next/link';
import { Footer } from '../components/Footer';
import { Header } from '../components/Header';

export const metadata: Metadata = { title: 'Strumenti', description: 'Strumenti semplici per tempo, denaro e vita quotidiana.', alternates: { canonical: '/strumenti' } };

const tools = [
  { icon: '€', title: 'Budget di famiglia', text: 'Un modello essenziale per parlare di soldi e scegliere insieme.', href: '/articoli/budget-famiglia-che-funziona' },
  { icon: '□', title: 'Settimana condivisa', text: 'Tre domande per vedere impegni, margini e priorità reali.', href: '/articoli/mattine-impegnative' },
  { icon: '◷', title: 'Confini del tempo', text: 'Una guida breve per iniziare e chiudere il lavoro con intenzione.', href: '/articoli/proteggi-il-tuo-tempo' },
];

export default function ToolsPage() {
  return (
    <>
      <Header />
      <main className="archive-page section-shell">
        <p className="eyebrow">Pronti da usare</p><h1>Strumenti</h1><p className="page-lede">Poche cose, progettate per entrare nella vita che hai già.</p>
        <div className="tool-grid">
          {tools.map((tool) => <Link href={tool.href} key={tool.title}><strong className="tool-icon">{tool.icon}</strong><h2>{tool.title}</h2><p>{tool.text}</p><span>Apri lo strumento <span aria-hidden="true">→</span></span></Link>)}
        </div>
      </main>
      <Footer />
    </>
  );
}

