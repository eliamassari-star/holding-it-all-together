import { notFound } from 'next/navigation';
import { getChatGPTUser, isAuthorizedEditor, localEditor } from '../chatgpt-auth';
import { StudioDashboard } from '../components/StudioDashboard';
import { publicAgentList } from '@/lib/editorial/agents';
import { marketPlaybook } from '@/lib/editorial/market-playbook';
import { listCycles } from '@/lib/editorial/repository';

export const dynamic = 'force-dynamic';

export const metadata = { title: 'Redazione AI', robots: { index: false, follow: false } };

export default function StudioPage() {
  return <StudioGate />;
}

async function StudioGate() {
  const user = localEditor() || await getChatGPTUser();
  if (!user) {
    return <main className="studio-signin"><p className="eyebrow">Area riservata</p><h1>Redazione AI</h1><p>Accedi con ChatGPT per aprire lo Studio editoriale.</p><a className="button" href="/signin-with-chatgpt?return_to=%2Fstudio">Accedi con ChatGPT →</a></main>;
  }
  if (process.env.NODE_ENV === 'production' && !isAuthorizedEditor(user)) notFound();
  const cycles = await listCycles();
  return <StudioDashboard initialCycles={cycles} agents={publicAgentList} playbook={{ spotify: marketPlaybook.spotify, youtube: marketPlaybook.youtube, newsletter: marketPlaybook.newsletter }} editorName={user.displayName} integrations={{ ai: process.env.OPENAI_API_KEY ? 'Attivo' : 'Modalità demo', newsletter: process.env.NEWSLETTER_PROVIDER && process.env.NEWSLETTER_PROVIDER !== 'mock' ? process.env.NEWSLETTER_PROVIDER : 'Da collegare', distribution: process.env.EDITORIAL_PUBLISH_WEBHOOK_URL ? 'Webhook attivo' : 'Pacchetti manuali' }} />;
}
