import { env } from 'cloudflare:workers';

export function getDatabase(): D1Database {
  if (!env.DB) throw new Error('Il database editoriale non è disponibile.');
  return env.DB;
}

const schemaStatements = [
  `CREATE TABLE IF NOT EXISTS editorial_cycles (
    id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    promise TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL,
    state TEXT NOT NULL,
    current_agent TEXT,
    approval_status TEXT NOT NULL DEFAULT 'pending',
    approved_version INTEGER,
    approved_channels TEXT NOT NULL DEFAULT '[]',
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_editorial_cycles_state ON editorial_cycles(state)`,
  `CREATE INDEX IF NOT EXISTS idx_editorial_cycles_updated_at ON editorial_cycles(updated_at)`,
  `CREATE TABLE IF NOT EXISTS editorial_artifacts (
    id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL REFERENCES editorial_cycles(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    version INTEGER NOT NULL,
    status TEXT NOT NULL,
    content_markdown TEXT NOT NULL,
    content_json TEXT NOT NULL,
    sources_json TEXT NOT NULL DEFAULT '[]',
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_editorial_artifacts_cycle_kind_version ON editorial_artifacts(cycle_id, kind, version)`,
  `CREATE INDEX IF NOT EXISTS idx_editorial_artifacts_cycle_id ON editorial_artifacts(cycle_id)`,
  `CREATE TABLE IF NOT EXISTS agent_runs (
    id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL REFERENCES editorial_cycles(id) ON DELETE CASCADE,
    agent_key TEXT NOT NULL,
    status TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    error TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT
  )`,
  `CREATE INDEX IF NOT EXISTS idx_agent_runs_cycle_id ON agent_runs(cycle_id)`,
  `CREATE TABLE IF NOT EXISTS approval_events (
    id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL REFERENCES editorial_cycles(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    decision TEXT NOT NULL,
    channels_json TEXT NOT NULL,
    notes TEXT NOT NULL DEFAULT '',
    actor TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_approval_events_cycle_id ON approval_events(cycle_id)`,
  `CREATE TABLE IF NOT EXISTS published_content (
    id TEXT PRIMARY KEY,
    content_type TEXT NOT NULL,
    slug TEXT NOT NULL,
    cycle_id TEXT NOT NULL REFERENCES editorial_cycles(id),
    content_json TEXT NOT NULL,
    published_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_published_content_type_slug ON published_content(content_type, slug)`,
  `CREATE INDEX IF NOT EXISTS idx_published_content_published_at ON published_content(published_at)`,
  `CREATE TABLE IF NOT EXISTS publication_events (
    id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL REFERENCES editorial_cycles(id),
    channel TEXT NOT NULL,
    status TEXT NOT NULL,
    external_id TEXT,
    url TEXT,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_publication_events_cycle_id ON publication_events(cycle_id)`,
  `CREATE TABLE IF NOT EXISTS newsletter_consents (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    event TEXT NOT NULL,
    source TEXT NOT NULL,
    privacy_version TEXT NOT NULL,
    tracking_consent INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_newsletter_consents_email ON newsletter_consents(email)`,
  `CREATE TABLE IF NOT EXISTS newsletter_suppressions (
    email TEXT PRIMARY KEY,
    reason TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`,
];

let initialized = false;

export async function ensureDatabase() {
  if (initialized) return;
  const database = getDatabase();
  await database.batch(schemaStatements.map((statement) => database.prepare(statement)));
  await database.prepare('PRAGMA optimize').run();
  initialized = true;
}
