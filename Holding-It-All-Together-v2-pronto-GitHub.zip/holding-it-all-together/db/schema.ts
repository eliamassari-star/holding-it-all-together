import { index, integer, sqliteTable, text, uniqueIndex } from 'drizzle-orm/sqlite-core';

export const editorialCycles = sqliteTable('editorial_cycles', {
  id: text('id').primaryKey(),
  topic: text('topic').notNull(),
  promise: text('promise').notNull().default(''),
  category: text('category').notNull(),
  state: text('state').notNull(),
  currentAgent: text('current_agent'),
  approvalStatus: text('approval_status').notNull().default('pending'),
  approvedVersion: integer('approved_version'),
  approvedChannels: text('approved_channels').notNull().default('[]'),
  createdBy: text('created_by').notNull(),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
}, (table) => [
  index('idx_editorial_cycles_state').on(table.state),
  index('idx_editorial_cycles_updated_at').on(table.updatedAt),
]);

export const editorialArtifacts = sqliteTable('editorial_artifacts', {
  id: text('id').primaryKey(),
  cycleId: text('cycle_id').notNull().references(() => editorialCycles.id, { onDelete: 'cascade' }),
  kind: text('kind').notNull(),
  version: integer('version').notNull(),
  status: text('status').notNull(),
  contentMarkdown: text('content_markdown').notNull(),
  contentJson: text('content_json').notNull(),
  sourcesJson: text('sources_json').notNull().default('[]'),
  createdBy: text('created_by').notNull(),
  createdAt: text('created_at').notNull(),
}, (table) => [
  uniqueIndex('idx_editorial_artifacts_cycle_kind_version').on(table.cycleId, table.kind, table.version),
  index('idx_editorial_artifacts_cycle_id').on(table.cycleId),
]);

export const agentRuns = sqliteTable('agent_runs', {
  id: text('id').primaryKey(),
  cycleId: text('cycle_id').notNull().references(() => editorialCycles.id, { onDelete: 'cascade' }),
  agentKey: text('agent_key').notNull(),
  status: text('status').notNull(),
  summary: text('summary').notNull().default(''),
  error: text('error'),
  createdAt: text('created_at').notNull(),
  completedAt: text('completed_at'),
}, (table) => [index('idx_agent_runs_cycle_id').on(table.cycleId)]);

export const approvalEvents = sqliteTable('approval_events', {
  id: text('id').primaryKey(),
  cycleId: text('cycle_id').notNull().references(() => editorialCycles.id, { onDelete: 'cascade' }),
  version: integer('version').notNull(),
  decision: text('decision').notNull(),
  channelsJson: text('channels_json').notNull(),
  notes: text('notes').notNull().default(''),
  actor: text('actor').notNull(),
  createdAt: text('created_at').notNull(),
}, (table) => [index('idx_approval_events_cycle_id').on(table.cycleId)]);

export const publishedContent = sqliteTable('published_content', {
  id: text('id').primaryKey(),
  contentType: text('content_type').notNull(),
  slug: text('slug').notNull(),
  cycleId: text('cycle_id').notNull().references(() => editorialCycles.id),
  contentJson: text('content_json').notNull(),
  publishedAt: text('published_at').notNull(),
  updatedAt: text('updated_at').notNull(),
}, (table) => [
  uniqueIndex('idx_published_content_type_slug').on(table.contentType, table.slug),
  index('idx_published_content_published_at').on(table.publishedAt),
]);

export const publicationEvents = sqliteTable('publication_events', {
  id: text('id').primaryKey(),
  cycleId: text('cycle_id').notNull().references(() => editorialCycles.id),
  channel: text('channel').notNull(),
  status: text('status').notNull(),
  externalId: text('external_id'),
  url: text('url'),
  detailsJson: text('details_json').notNull().default('{}'),
  createdAt: text('created_at').notNull(),
}, (table) => [index('idx_publication_events_cycle_id').on(table.cycleId)]);

export const newsletterConsents = sqliteTable('newsletter_consents', {
  id: text('id').primaryKey(),
  email: text('email').notNull(),
  event: text('event').notNull(),
  source: text('source').notNull(),
  privacyVersion: text('privacy_version').notNull(),
  trackingConsent: integer('tracking_consent', { mode: 'boolean' }).notNull().default(false),
  createdAt: text('created_at').notNull(),
}, (table) => [index('idx_newsletter_consents_email').on(table.email)]);

export const newsletterSuppressions = sqliteTable('newsletter_suppressions', {
  email: text('email').primaryKey(),
  reason: text('reason').notNull(),
  createdAt: text('created_at').notNull(),
});
