# Redazione AI — Modello operativo

## 1. Scopo

Questo documento definisce la redazione AI di **Holding It All Together**: ruoli, responsabilità, passaggi di consegna, controlli e roadmap necessari per trasformare il sito attuale in un sistema editoriale continuativo.

La configurazione implementata assume:

- contenuti e artefatti conservati in D1 con versioni immutabili; i contenuti dimostrativi restano in `app/data/content.ts` come fallback;
- approvazione umana obbligatoria prima di ogni pubblicazione;
- podcast registrato da persone, con preparazione editoriale assistita dall'AI;
- un ciclo editoriale settimanale composto da articolo, episodio podcast e newsletter coordinati;
- nessuna modifica autonoma a infrastruttura, accessi, credenziali o pagine legali.

Queste scelte sono valori predefiniti, non vincoli permanenti. Potranno essere modificate quando il sistema avrà dimostrato affidabilità.

## 2. Principi di funzionamento

1. **Una responsabilità per ruolo.** Ogni agente deve avere un mandato limitato e un risultato verificabile.
2. **Una sola fonte di verità.** Brief, fonti, bozze, approvazioni e contenuti pubblicati devono essere registrati nel progetto.
3. **Nessuna pubblicazione implicita.** Solo il Publisher può pubblicare, e soltanto dopo un'approvazione valida.
4. **Fonti prima della prosa.** L'autore e il produttore podcast lavorano su un dossier verificato, non su ricordi o supposizioni.
5. **Separazione tra contenuto e piattaforma.** Gli agenti editoriali non modificano il codice del sito; il Site Manager non riscrive i contenuti senza un incarico editoriale.
6. **Tracciabilità.** Ogni passaggio registra autore, data, versione, stato e motivazione delle modifiche.
7. **Riutilizzo intelligente.** Articolo, podcast e newsletter condividono la stessa ricerca, ma non devono essere copie dello stesso testo.
8. **Escalation umana.** Dubbi sulle fonti, temi sensibili, conflitti editoriali e modifiche irreversibili vengono fermati e sottoposti al proprietario.

## 3. Flusso editoriale

```text
Obiettivi del progetto
        ↓
Caporedattore → Scout → Ricercatore
        ↓                    ↓
        └──── brief approvato ┘
                  ↓
         Autore + Produttore podcast
                  ↓
                Revisore
                  ↓
        Asset e pacchetto editoriale
                  ↓
          APPROVAZIONE UMANA
                  ↓
               Publisher
          ↙          ↓          ↘
       Sito      Newsletter    Podcast
          ↘          ↓          ↙
        Site Manager e Analista
                  ↓
        indicazioni al Caporedattore
```

## 4. Stati del contenuto

Ogni unità editoriale possiede uno stato univoco.

| Stato | Significato | Può avanzare solo se |
|---|---|---|
| `idea` | Proposta non ancora valutata | Sono presenti problema del lettore e motivazione |
| `selected` | Argomento scelto | Il Caporedattore ha creato il brief |
| `researching` | Ricerca in corso | Lo scope è chiaro |
| `ready_for_draft` | Dossier concluso | Fonti e affermazioni sono tracciabili |
| `drafting` | Produzione dei contenuti | Articolo e podcast usano lo stesso brief |
| `review` | Controllo editoriale e fattuale | Tutti i materiali obbligatori sono presenti |
| `changes_requested` | Sono necessarie correzioni | Il Revisore indica problemi e criterio di accettazione |
| `ready_for_approval` | Pacchetto completo | Revisione superata e asset pronti |
| `approved` | Approvazione umana registrata | Esiste un'approvazione esplicita per quella versione |
| `scheduled` | Data e canali definiti | Il Publisher ha completato i controlli pre-pubblicazione |
| `published` | Contenuto online | URL e orario di pubblicazione sono registrati |
| `measuring` | Raccolta risultati | È trascorso il periodo minimo di osservazione |
| `archived` | Ciclo concluso | Report e apprendimenti sono stati salvati |

Un contenuto modificato dopo l'approvazione torna automaticamente a `review`. L'approvazione non si trasferisce tra versioni.

## 5. Contratto comune degli agenti

Ogni agente riceve un incarico strutturato con:

- `job_id`: identificatore univoco;
- `content_id`: identificatore dell'unità editoriale;
- `current_state`: stato di partenza;
- `objective`: risultato richiesto;
- `inputs`: file e dati autorizzati;
- `constraints`: limiti editoriali e tecnici;
- `due_at`: scadenza;
- `requested_by`: ruolo che ha effettuato la consegna.

Ogni agente restituisce:

- `status`: `completed`, `changes_requested`, `blocked` oppure `failed`;
- `output_files`: materiali prodotti o modificati;
- `summary`: sintesi del lavoro;
- `checks`: controlli effettuati;
- `open_questions`: decisioni non risolvibili autonomamente;
- `handoff_to`: agente o persona successiva;
- `provenance`: fonti, strumenti e versione degli input utilizzati.

Un agente non può dichiarare `completed` se mancano elementi previsti dalla propria definizione di completamento.

## 6. Gli otto agenti

### 6.1 Caporedattore — Orchestratore

**Missione:** trasformare gli obiettivi del progetto in un piano editoriale coerente e coordinare l'intero ciclo.

**Riceve:** principi editoriali, calendario, risultati precedenti, proposte dello Scout, disponibilità e vincoli.

**Produce:** priorità, brief approvato, assegnazioni, scadenze e decisione finale su eventuali conflitti tra agenti.

**Può:** scegliere e scartare idee, richiedere approfondimenti, cambiare una scadenza, interrompere un ciclo incompleto.

**Non può:** pubblicare, approvare al posto del proprietario, inventare fonti, modificare il sito o cambiare autonomamente la linea editoriale.

**Completato quando:** il brief contiene pubblico, problema, promessa, angolo, formato, fonti richieste, call to action, rischi e criteri di successo.

### 6.2 Scout argomenti

**Missione:** individuare argomenti utili e pertinenti, evitando una rincorsa indiscriminata ai trend.

**Riceve:** categorie del sito, pubblico, archivio dei contenuti, domande raccolte, performance passate e calendario stagionale.

**Produce:** massimo cinque proposte per ciclo, ordinate e motivate.

Ogni proposta deve includere:

- domanda reale a cui risponde;
- categoria primaria e secondaria;
- motivo per cui è rilevante adesso;
- possibile titolo e angolo distintivo;
- potenziale per articolo, podcast e newsletter;
- contenuti già pubblicati da aggiornare o collegare;
- livello di rischio e fabbisogno di ricerca.

**Non può:** selezionare autonomamente l'argomento definitivo, copiare titoli concorrenti o proporre temi estranei alla linea editoriale solo perché popolari.

**Completato quando:** ogni proposta è specifica, non duplicata e collegata a un bisogno del pubblico.

### 6.3 Ricercatore

**Missione:** creare un dossier affidabile che distingua fatti, interpretazioni, esempi e ipotesi.

**Riceve:** brief selezionato, policy sulle fonti, archivio interno e domande del Caporedattore.

**Produce:** dossier con sintesi, evidenze, citazioni utilizzabili, esempi, punti controversi e lacune.

**Regole sulle fonti:**

- preferire fonti primarie, istituzionali e studi originali;
- registrare URL, autore, data di pubblicazione e data di consultazione;
- non trasformare correlazioni in causalità;
- segnalare dati vecchi, conflitti tra fonti e limiti metodologici;
- per salute, finanza, diritto e sicurezza richiedere revisione umana specialistica;
- non includere nel dossier affermazioni prive di fonte presentandole come fatti.

**Completato quando:** ogni affermazione verificabile proposta per la pubblicazione è collegata a una fonte o marcata come esperienza/opinione.

### 6.4 Autore articoli

**Missione:** trasformare brief e dossier in un articolo chiaro, umano e utile.

**Riceve:** brief, dossier, costituzione editoriale, template dell'articolo e collegamenti interni suggeriti.

**Produce:** titolo, descrizione, corpo, box pratici, CTA, metadati SEO e suggerimenti visuali.

**Regole:**

- scrivere in italiano naturale e concreto;
- aprire con una situazione riconoscibile, non con definizioni astratte;
- mantenere una promessa centrale per articolo;
- non aggiungere fatti che non compaiono nel dossier;
- evitare tono paternalistico, ansia artificiale, perfezionismo e soluzioni assolute;
- utilizzare esempi realistici senza presentarli come testimonianze autentiche se sono compositi;
- proporre collegamenti a contenuti esistenti quando pertinenti.

**Completato quando:** il testo soddisfa il brief, tutte le affermazioni sono tracciabili e la CTA è coerente con l'obiettivo del ciclo.

### 6.5 Produttore podcast

**Missione:** creare un episodio complementare all'articolo, progettato per l'ascolto e non come lettura del testo scritto.

**Riceve:** brief, dossier, bozza dell'articolo, formato del podcast e durata obiettivo.

**Produce:** concept, apertura, scaletta temporale, copione o traccia per il conduttore, domande, show notes, capitoli, descrizione, CTA e traccia per la trascrizione.

**Regole:**

- utilizzare ritmo e linguaggio parlato;
- aggiungere prospettive o esempi che valorizzano l'audio;
- indicare chiaramente pause, transizioni e parti da improvvisare;
- non simulare ospiti, testimonianze o registrazioni reali;
- non generare o pubblicare una voce sintetica senza una decisione esplicita del proprietario;
- prevedere una verifica finale tra audio registrato e show notes.

**Completato quando:** il pacchetto può essere registrato da una persona senza ulteriori decisioni strutturali.

### 6.6 Revisore editoriale e fact-checker

**Missione:** essere indipendente dagli autori e impedire che contenuti deboli, incoerenti o non verificati arrivino all'approvazione.

**Riceve:** brief, dossier, articolo, pacchetto podcast, fonti e costituzione editoriale.

**Produce:** rapporto di revisione con esito `approved_for_human_review` oppure `changes_requested`.

Controlla:

- corrispondenza con il brief;
- accuratezza e copertura delle fonti;
- coerenza tra articolo, podcast e newsletter;
- tono di voce, chiarezza e utilità;
- titoli ingannevoli, ripetizioni e promesse non mantenute;
- rischi legali, sanitari, finanziari, reputazionali o di privacy;
- presenza di CTA, metadata e collegamenti necessari;
- originalità rispetto all'archivio interno.

**Non può:** correggere silenziosamente un fatto sostanziale. Deve restituire il contenuto all'agente responsabile indicando problema, evidenza e criterio di accettazione.

**Completato quando:** ogni controllo ha un esito registrato e non esistono criticità aperte.

### 6.7 Publisher e distribuzione

**Missione:** trasformare un pacchetto approvato nella sua versione pubblica su tutti i canali previsti.

**Riceve:** versione approvata, asset finali, data di pubblicazione, canali, CTA e autorizzazione umana.

**Produce:** contenuti strutturati, anteprima, programmazione, pubblicazione, newsletter e messaggi di distribuzione.

Controlli obbligatori prima della pubblicazione:

- l'approvazione appartiene alla versione corrente;
- slug e URL sono corretti e non duplicati;
- titolo, descrizione, immagine e testo alternativo sono presenti;
- collegamenti interni ed esterni funzionano;
- data, autore, categoria e metadata SEO sono corretti;
- articolo, episodio, feed e newsletter puntano agli URL definitivi;
- anteprima desktop e mobile superano il controllo visuale;
- non sono presenti credenziali, note interne o segnaposto.

**Non può:** modificare sostanzialmente i testi approvati, pubblicare senza autorizzazione o cambiare il pubblico del sito.

**Completato quando:** URL, orari, canali e risultato dei controlli sono registrati; ogni errore di pubblicazione viene segnalato senza nasconderlo.

### 6.8 Site Manager e Analista

**Missione:** mantenere affidabile il sito e trasformare i risultati in indicazioni operative.

**Riceve:** URL pubblicati, log tecnici, dati di traffico e conversione, obiettivi del ciclo e segnalazioni degli utenti.

**Produce:** controllo post-pubblicazione, report sintetico e proposte per il ciclo successivo.

Controlla:

- disponibilità delle pagine e dei feed;
- errori applicativi e collegamenti interrotti;
- resa responsive e regressioni visuali;
- prestazioni principali;
- funzionamento di iscrizione, preferenze e disiscrizione;
- indicizzazione, sitemap e metadata;
- letture, completamento, iscrizioni, ascolti e CTA;
- confronto con la baseline, senza confondere oscillazioni casuali con tendenze.

**Può:** correggere problemi tecnici reversibili e chiaramente delimitati, se autorizzato dal piano operativo.

**Non può:** cambiare concept, palette, composizione, accessi, provider o strategia editoriale senza approvazione.

**Completato quando:** il contenuto è raggiungibile, i flussi essenziali funzionano e il report distingue dati, interpretazioni e raccomandazioni.

## 7. Costituzione editoriale condivisa

Tutti gli agenti devono leggere la stessa costituzione prima di operare. La prima versione dovrà contenere almeno:

### Pubblico

Persone adulte che cercano modi realistici per gestire lavoro, denaro, famiglia, benessere e organizzazione senza inseguire la perfezione.

### Promessa

Offrire idee pratiche, storie credibili e strumenti utilizzabili per rendere la vita quotidiana più gestibile.

### Voce

- calma, concreta e rispettosa;
- competente senza essere accademica;
- empatica senza sentimentalismo artificiale;
- positiva senza minimizzare le difficoltà;
- mai giudicante o prescrittiva.

### Regole linguistiche

- frasi prevalentemente brevi;
- esempi quotidiani;
- terminologia specialistica spiegata quando indispensabile;
- niente clickbait, superlativi non dimostrabili o promesse assolute;
- niente urgenza artificiale;
- inviti all'azione chiari ma non aggressivi.

### Confini

- il sito non sostituisce consulenze mediche, finanziarie, legali o psicologiche;
- non pubblica dati personali senza consenso;
- non inventa statistiche, citazioni, esperti o testimonianze;
- non usa immagini ingannevoli come prova di eventi reali;
- segnala contenuti sponsorizzati, affiliazioni e conflitti d'interesse.

## 8. Archivio versionato implementato

Il database D1 è la fonte di verità della redazione. Conserva cicli, esecuzioni degli agenti, artefatti immutabili, approvazioni, eventi di pubblicazione, contenuti pubblici e consensi newsletter. Ogni nuovo passaggio crea una versione anziché sovrascrivere quella precedente.

Le pagine pubbliche uniscono i record pubblicati in D1 ai contenuti dimostrativi di `app/data/content.ts`; in questo modo il sito resta completo anche prima del primo ciclo reale. Brief, dossier, revisioni e approvazioni sono accessibili soltanto nello Studio e non entrano nelle pagine pubbliche.

## 9. Matrice delle autorizzazioni

| Azione | Automatica | Richiede approvazione |
|---|:---:|:---:|
| Proporre argomenti | Sì | No |
| Preparare ricerca e bozze | Sì | No |
| Richiedere correzioni | Sì | No |
| Generare immagini di bozza | Sì | No |
| Approvare il pacchetto finale | No | Sì |
| Pubblicare o programmare | No | Sì, nella fase iniziale |
| Inviare newsletter | No | Sì |
| Modificare contenuti già online | No | Sì |
| Correggere un link rotto senza cambiare il significato | Sì, se preautorizzato | Altrimenti sì |
| Modificare codice, layout o design system | No | Sì |
| Cambiare accessi, domini, provider o credenziali | No | Sì |
| Eliminare contenuti o dati | No | Sì |

## 10. Gestione delle eccezioni

Un agente interrompe il proprio lavoro e chiede intervento quando:

- il brief è ambiguo in modo sostanziale;
- due fonti affidabili si contraddicono;
- servono dati personali o credenziali non disponibili;
- il contenuto può produrre danni se interpretato come consulenza;
- manca il diritto di utilizzare un asset;
- la pubblicazione comporta un cambiamento di pubblico o un invio esterno non approvato;
- il risultato richiede di alterare concept, palette o composizione del sito;
- lo stesso errore si ripete dopo due tentativi di correzione.

Ogni blocco deve spiegare: che cosa è successo, che cosa è già stato verificato, quale decisione serve e quali sono le alternative sicure.

## 11. Ciclo pilota settimanale

### Giorno 1 — Scelta

- lo Scout consegna cinque proposte;
- il Caporedattore ne sceglie una e crea il brief;
- il proprietario interviene solo se il tema è sensibile o fuori dalla linea ordinaria.

### Giorno 2 — Ricerca

- il Ricercatore prepara il dossier;
- il Caporedattore verifica copertura e angolo;
- eventuali lacune vengono risolte prima della scrittura.

### Giorni 3 e 4 — Produzione

- l'Autore prepara l'articolo;
- il Produttore podcast prepara l'episodio;
- il pacchetto newsletter viene derivato dai due contenuti senza duplicarli.

### Giorno 5 — Revisione e approvazione

- il Revisore effettua controllo editoriale e fact-checking;
- gli autori applicano le correzioni;
- il proprietario riceve un'unica anteprima con riepilogo delle fonti e approva la versione.

### Pubblicazione

- il Publisher programma articolo, episodio e newsletter;
- esegue i controlli visuali e tecnici;
- registra URL e orari definitivi.

### Dopo la pubblicazione

- il Site Manager controlla immediatamente pagine, feed e form;
- l'Analista produce un primo report dopo 48 ore e un secondo dopo 7 giorni;
- gli apprendimenti entrano nel brief della settimana successiva.

## 12. Indicatori iniziali

Per i primi otto cicli misureremo pochi indicatori leggibili:

- percentuale di proposte accettate;
- numero medio di revisioni per contenuto;
- tempo dalla selezione alla pubblicazione;
- percentuale di articoli letti oltre il punto medio;
- iscrizioni newsletter per contenuto;
- avvii e completamenti del podcast, quando disponibili;
- click sulla CTA principale;
- errori o correzioni richieste dopo la pubblicazione;
- quota di testo modificata dall'approvatore umano.

L'obiettivo iniziale non è massimizzare il volume, ma ridurre errori e revisioni mantenendo riconoscibile la voce del progetto.

## 13. Stato dell'implementazione

### Fase 1 — Fondamenta editoriali — completata

- completare costituzione editoriale e profilo del pubblico;
- definire template per brief, dossier, articolo, podcast, newsletter e revisione;
- creare manifest e stati del workflow;
- migrare i contenuti dimostrativi dal file TypeScript ai contenuti versionati.

**Esito:** il sito continua a funzionare, ma i contenuti sono separati dal codice e pronti per gli agenti.

### Fase 2 — Redazione assistita — completata

- implementare Caporedattore, Scout, Ricercatore, Autore, Produttore e Revisore;
- eseguire un ciclo pilota completo senza pubblicazione automatica;
- confrontare ogni artefatto con una revisione umana.

**Esito:** un pacchetto editoriale completo pronto per l'approvazione.

### Fase 3 — Pubblicazione controllata — completata lato sito

- implementare il Publisher;
- aggiungere anteprima, approvazione versionata e programmazione;
- collegare, tramite variabili d'ambiente, provider newsletter e hosting podcast reali;
- verificare rollback e correzione post-pubblicazione.

**Esito:** pubblicazione multicanale con conferma umana obbligatoria.

### Fase 4 — Gestione e apprendimento — base implementata

- implementare Site Manager e Analista;
- collegare dati di traffico, conversione e ascolto;
- produrre report settimanali;
- permettere al Caporedattore di usare i risultati senza modificare autonomamente la strategia.

**Esito:** ciclo editoriale chiuso e misurabile.

### Fase 5 — Autonomia selettiva — da valutare dopo otto cicli

- valutare i risultati dei primi otto cicli;
- autorizzare solo azioni ripetitive con rischio basso;
- mantenere approvazione umana per pubblicazione, temi sensibili, cambi strutturali e accessi finché non viene presa una decisione diversa.

## 14. Utilizzo

Lo Studio è disponibile su `/studio`. Il proprietario genera idee, apre un ciclo, avanza gli agenti, ispeziona fonti e versioni, sceglie i canali, approva esplicitamente e infine pubblica. In assenza di `OPENAI_API_KEY` il flusso usa una modalità dimostrativa deterministica; con la chiave configurata utilizza la Responses API e la ricerca web per Scout e Ricercatore.
