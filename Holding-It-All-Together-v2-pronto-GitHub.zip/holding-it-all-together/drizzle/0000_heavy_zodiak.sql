CREATE TABLE `agent_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`cycle_id` text NOT NULL,
	`agent_key` text NOT NULL,
	`status` text NOT NULL,
	`summary` text DEFAULT '' NOT NULL,
	`error` text,
	`created_at` text NOT NULL,
	`completed_at` text,
	FOREIGN KEY (`cycle_id`) REFERENCES `editorial_cycles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_agent_runs_cycle_id` ON `agent_runs` (`cycle_id`);--> statement-breakpoint
CREATE TABLE `approval_events` (
	`id` text PRIMARY KEY NOT NULL,
	`cycle_id` text NOT NULL,
	`version` integer NOT NULL,
	`decision` text NOT NULL,
	`channels_json` text NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`actor` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`cycle_id`) REFERENCES `editorial_cycles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_approval_events_cycle_id` ON `approval_events` (`cycle_id`);--> statement-breakpoint
CREATE TABLE `editorial_artifacts` (
	`id` text PRIMARY KEY NOT NULL,
	`cycle_id` text NOT NULL,
	`kind` text NOT NULL,
	`version` integer NOT NULL,
	`status` text NOT NULL,
	`content_markdown` text NOT NULL,
	`content_json` text NOT NULL,
	`sources_json` text DEFAULT '[]' NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`cycle_id`) REFERENCES `editorial_cycles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_editorial_artifacts_cycle_kind_version` ON `editorial_artifacts` (`cycle_id`,`kind`,`version`);--> statement-breakpoint
CREATE INDEX `idx_editorial_artifacts_cycle_id` ON `editorial_artifacts` (`cycle_id`);--> statement-breakpoint
CREATE TABLE `editorial_cycles` (
	`id` text PRIMARY KEY NOT NULL,
	`topic` text NOT NULL,
	`promise` text DEFAULT '' NOT NULL,
	`category` text NOT NULL,
	`state` text NOT NULL,
	`current_agent` text,
	`approval_status` text DEFAULT 'pending' NOT NULL,
	`approved_version` integer,
	`approved_channels` text DEFAULT '[]' NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_editorial_cycles_state` ON `editorial_cycles` (`state`);--> statement-breakpoint
CREATE INDEX `idx_editorial_cycles_updated_at` ON `editorial_cycles` (`updated_at`);--> statement-breakpoint
CREATE TABLE `newsletter_consents` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`event` text NOT NULL,
	`source` text NOT NULL,
	`privacy_version` text NOT NULL,
	`tracking_consent` integer DEFAULT false NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_newsletter_consents_email` ON `newsletter_consents` (`email`);--> statement-breakpoint
CREATE TABLE `newsletter_suppressions` (
	`email` text PRIMARY KEY NOT NULL,
	`reason` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `publication_events` (
	`id` text PRIMARY KEY NOT NULL,
	`cycle_id` text NOT NULL,
	`channel` text NOT NULL,
	`status` text NOT NULL,
	`external_id` text,
	`url` text,
	`details_json` text DEFAULT '{}' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`cycle_id`) REFERENCES `editorial_cycles`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_publication_events_cycle_id` ON `publication_events` (`cycle_id`);--> statement-breakpoint
CREATE TABLE `published_content` (
	`id` text PRIMARY KEY NOT NULL,
	`content_type` text NOT NULL,
	`slug` text NOT NULL,
	`cycle_id` text NOT NULL,
	`content_json` text NOT NULL,
	`published_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`cycle_id`) REFERENCES `editorial_cycles`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_published_content_type_slug` ON `published_content` (`content_type`,`slug`);--> statement-breakpoint
CREATE INDEX `idx_published_content_published_at` ON `published_content` (`published_at`);