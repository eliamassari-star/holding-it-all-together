import type { AgentKey, CycleState } from './types';

export type AgentDefinition = {
  key: AgentKey;
  name: string;
  shortName: string;
  description: string;
  artifactKind: string;
  usesWeb: boolean;
  instructions: string;
};

export const agentDefinitions: Record<AgentKey, AgentDefinition> = {
  editor_in_chief: {
    key: 'editor_in_chief',
    name: 'Caporedattore',
    shortName: 'Direzione',
    description: 'Trasforma l’argomento in un brief con promessa, pubblico, angolo e criteri di successo.',
    artifactKind: 'brief',
    usesWeb: false,
    instructions: 'Crea un brief editoriale. artifact deve contenere audience, reader_problem, promise, angle, primary_category, secondary_categories, article_goal, podcast_goal, newsletter_goal, call_to_action, risks, success_metrics.',
  },
  topic_scout: {
    key: 'topic_scout',
    name: 'Scout argomenti',
    shortName: 'Scout',
    description: 'Trova cinque opportunità editoriali attuali, utili e non duplicate.',
    artifactKind: 'ideas',
    usesWeb: true,
    instructions: 'Proponi esattamente cinque idee. artifact deve contenere ideas: array di oggetti con title, reader_question, why_now, category, angle, article_potential, podcast_potential, newsletter_potential, risk_level.',
  },
  researcher: {
    key: 'researcher',
    name: 'Ricercatore',
    shortName: 'Ricerca',
    description: 'Costruisce un dossier distinguendo fatti, interpretazioni e limiti.',
    artifactKind: 'research',
    usesWeb: true,
    instructions: 'Prepara un dossier verificabile. artifact deve contenere executive_summary, key_findings, claims (claim, source_url, confidence, caveat), examples, counterpoints, unanswered_questions. Preferisci fonti primarie e recenti.',
  },
  article_writer: {
    key: 'article_writer',
    name: 'Autore articoli',
    shortName: 'Articolo',
    description: 'Scrive articolo e bozza newsletter con tono concreto e non giudicante.',
    artifactKind: 'article',
    usesWeb: false,
    instructions: 'Produci il pacchetto completo una sola volta. ARTICOLO: article.body deve contenere esattamente 10 paragrafi sostanziali di 145–175 parole ciascuno; così il totale obbligatorio resta tra 1.400 e 1.900 parole. NEWSLETTER: introduction deve avere 55–65 parole; crea esattamente 3 sections, ognuna con un solo paragraph di 55–75 parole; primaryCta deve avere 5–12 parole. Il totale obbligatorio della newsletter, calcolato su introduction + paragraphs + primaryCta, deve essere 220–380 parole. Non usare testi segnaposto, riassunti di poche righe o campi vuoti. artifact deve essere un oggetto, non una stringa, e deve contenere article con slug, category, title, description, readingTime, date, image, body (array di paragrafi), seoTitle, seoDescription, sourceUrls; e newsletter_draft con subject, previewText, title, introduction, sections, primaryCta. Usa solo fatti presenti nel dossier. Apri l’articolo con una risposta utile entro le prime 100 parole e concludi con una sola azione concreta. La newsletter deve essere autonoma e avere una sola CTA. Prima di rispondere verifica i conteggi. artifact_markdown deve essere soltanto un indice sintetico: non duplicare i testi presenti in artifact.',
  },
  podcast_producer: {
    key: 'podcast_producer',
    name: 'Produttore podcast',
    shortName: 'Podcast',
    description: 'Progetta episodio video-first, copione, capitoli e clip native.',
    artifactKind: 'podcast',
    usesWeb: false,
    instructions: 'Produci il pacchetto completo una sola volta. PODCAST: crea esattamente 6 script_sections; ogni spoken_text deve avere 520–600 parole. La loro somma obbligatoria deve restare tra 3.000 e 3.800 parole. Non duplicare il copione in transcript: il sistema genera automaticamente la trascrizione dalle sezioni. Entra nel tema entro 70 parole e porta il primo risultato concreto entro due minuti. CLIP: spotify_clip.script deve avere 75–95 parole, entro il limite obbligatorio di 60–110, e duration_seconds deve essere 30–45. artifact deve essere un oggetto, non una stringa, e deve contenere slug, number, title, date, duration, description, image, opening_hook, showNotes, chapters (time,title), script_sections (title,spoken_text), links, spotify_clip (hook,script,duration_seconds), youtube (title,description,thumbnail_text,shorts), recording_checklist. Il contenuto deve funzionare anche senza immagini. Prima di rispondere verifica i conteggi. artifact_markdown deve essere soltanto una scaletta sintetica: non duplicare il copione presente in artifact.',
  },
  reviewer: {
    key: 'reviewer',
    name: 'Revisore e fact-checker',
    shortName: 'Revisione',
    description: 'Controlla fonti, tono, coerenza, rischi e adeguatezza ai canali.',
    artifactKind: 'review',
    usesWeb: false,
    instructions: 'Esegui una revisione indipendente. artifact deve contenere verdict (pass o changes_requested), factual_findings, editorial_findings, market_findings, legal_privacy_findings, required_changes, approved_claims. Non correggere silenziosamente fatti sostanziali.',
  },
  publisher: {
    key: 'publisher',
    name: 'Publisher e distribuzione',
    shortName: 'Publisher',
    description: 'Prepara i record pubblici e il pacchetto operativo per newsletter, Spotify e YouTube.',
    artifactKind: 'distribution',
    usesWeb: false,
    instructions: 'Crea il pacchetto di distribuzione senza cambiare i contenuti approvati. artifact deve contenere newsletter, spotify, youtube, site, preflight_checks e rollback_plan. Segnala ogni campo mancante come blocked, non inventare URL esterni.',
  },
  site_manager_analyst: {
    key: 'site_manager_analyst',
    name: 'Site Manager e Analista',
    shortName: 'Controllo',
    description: 'Verifica pubblicabilità, salute tecnica e risultati del ciclo.',
    artifactKind: 'quality_report',
    usesWeb: false,
    instructions: 'Se il ciclo non è pubblicato, produci un preflight; se è pubblicato, produci un report post-pubblicazione. artifact deve contenere phase, checks, blockers, warnings, metrics, recommendations. Non inventare metriche mancanti.',
  },
};

export const workflowAgentForState: Partial<Record<CycleState, AgentKey>> = {
  selected: 'editor_in_chief',
  brief_ready: 'researcher',
  research_ready: 'article_writer',
  article_ready: 'podcast_producer',
  podcast_ready: 'reviewer',
  changes_requested: 'article_writer',
  review_ready: 'site_manager_analyst',
  approved: 'publisher',
  published: 'site_manager_analyst',
};

export function nextStateAfterAgent(agent: AgentKey, currentState: CycleState): CycleState {
  if (agent === 'editor_in_chief') return 'brief_ready';
  if (agent === 'researcher') return 'research_ready';
  if (agent === 'article_writer') return 'article_ready';
  if (agent === 'podcast_producer') return 'podcast_ready';
  if (agent === 'reviewer') return 'review_ready';
  if (agent === 'site_manager_analyst') return currentState === 'published' ? 'archived' : 'ready_for_approval';
  if (agent === 'publisher') return 'published';
  return currentState;
}

export const publicAgentList = Object.values(agentDefinitions).map(({ key, name, shortName, description, usesWeb }) => ({ key, name, shortName, description, usesWeb }));
