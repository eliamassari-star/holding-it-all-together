import { agentDefinitions } from './agents';
import { marketRulesForPrompt } from './market-playbook';
import type { AgentKey, AgentResult, EditorialArtifact, EditorialCycle } from './types';

const OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    summary: { type: 'string' },
    artifact_markdown: { type: 'string' },
    artifact: { type: 'object', description: 'Contenuto editoriale strutturato conforme alla forma richiesta nelle istruzioni.' },
    checks: { type: 'array', items: { type: 'string' } },
    open_questions: { type: 'array', items: { type: 'string' } },
    ready: { type: 'boolean' },
  },
  required: ['summary', 'artifact_markdown', 'artifact', 'checks', 'open_questions', 'ready'],
} as const;

const constitution = `
Sei parte della redazione di Holding It All Together — Work. Money. Family. Life.
Pubblico: adulti che cercano modi realistici per gestire lavoro, denaro, famiglia, benessere e organizzazione senza inseguire la perfezione.
Voce: calma, concreta, competente, empatica, mai paternalistica o sensazionalistica.
Non inventare dati, citazioni, persone, testimonianze o risultati. Distingui fatti, interpretazioni e suggerimenti.
Salute, finanza, diritto, privacy e sicurezza richiedono particolare cautela e non devono sembrare consulenza professionale.
Scrivi in italiano naturale. Una promessa centrale, esempi quotidiani, nessuna urgenza artificiale.
`;

const editorialLengths = {
  article: { target: 1600, min: 1400, max: 1900 },
  newsletter: { target: 300, min: 220, max: 380 },
  podcast: { target: 3400, min: 3000, max: 3800 },
  clip: { min: 60, max: 110 },
} as const;

function words(value: unknown): number {
  const text = Array.isArray(value)
    ? value.map((item) => typeof item === 'object' && item ? wordsSource(item) : String(item || '')).join(' ')
    : wordsSource(value);
  return text.match(/[\p{L}\p{N}]+(?:[’'][\p{L}\p{N}]+)*/gu)?.length || 0;
}

function wordsSource(value: unknown): string {
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(wordsSource).join(' ');
  if (value && typeof value === 'object') return Object.values(value as Record<string, unknown>).map(wordsSource).join(' ');
  return '';
}

function validateLengths(agentKey: AgentKey, artifact: Record<string, unknown>) {
  const checks: string[] = [];
  const issues: string[] = [];
  const outside = (label: string, count: number, range: { min: number; max: number }) => {
    if (count < range.min || count > range.max) {
      issues.push(`${label}: ${count} parole; richieste ${range.min}–${range.max}`);
      return;
    }
    checks.push(`${label}: ${count} parole`);
  };

  if (agentKey === 'article_writer') {
    const article = (artifact.article || {}) as Record<string, unknown>;
    const newsletter = (artifact.newsletter_draft || {}) as Record<string, unknown>;
    const newsletterSections = Array.isArray(newsletter.sections) ? newsletter.sections : [];
    const articleCount = words(article.body);
    const newsletterCount = words({
      introduction: newsletter.introduction,
      paragraphs: newsletterSections.map((section) => (section as Record<string, unknown>)?.paragraphs),
      primaryCta: newsletter.primaryCta,
    });
    outside('Articolo', articleCount, editorialLengths.article);
    outside('Newsletter', newsletterCount, editorialLengths.newsletter);
    artifact.word_counts = { article: articleCount, newsletter: newsletterCount };
  }

  if (agentKey === 'podcast_producer') {
    const sections = Array.isArray(artifact.script_sections) ? artifact.script_sections : [];
    const podcastCount = words(sections.map((section) => (section as Record<string, unknown>)?.spoken_text));
    outside('Podcast', podcastCount, editorialLengths.podcast);
    const spotifyClip = (artifact.spotify_clip || {}) as Record<string, unknown>;
    const clipCount = words(spotifyClip.script);
    outside('Clip', clipCount, editorialLengths.clip);
    artifact.transcript = sections.map((section) => String((section as Record<string, unknown>)?.spoken_text || '')).filter(Boolean);
    artifact.duration = `${Math.round(podcastCount / 140)} min`;
    artifact.word_counts = { podcast: podcastCount, spotify_clip: clipCount };
  }

  return { checks, issues };
}

function extractOutputText(payload: Record<string, unknown>) {
  if (typeof payload.output_text === 'string') return payload.output_text;
  const output = Array.isArray(payload.output) ? payload.output : [];
  for (const item of output) {
    if (!item || typeof item !== 'object') continue;
    const content = Array.isArray((item as { content?: unknown }).content) ? (item as { content: unknown[] }).content : [];
    for (const part of content) {
      if (part && typeof part === 'object' && typeof (part as { text?: unknown }).text === 'string') return (part as { text: string }).text;
    }
  }
  throw new Error('Il modello non ha restituito un contenuto leggibile.');
}

function extractSources(payload: Record<string, unknown>) {
  const found = new Map<string, string>();
  const output = Array.isArray(payload.output) ? payload.output : [];
  const visit = (value: unknown) => {
    if (!value || typeof value !== 'object') return;
    const object = value as Record<string, unknown>;
    if (typeof object.url === 'string' && object.url.startsWith('http')) {
      found.set(object.url, typeof object.title === 'string' ? object.title : object.url);
    }
    Object.values(object).forEach((child) => Array.isArray(child) ? child.forEach(visit) : visit(child));
  };
  output.forEach(visit);
  return [...found].map(([url, title]) => ({ title, url })).slice(0, 20);
}

export async function runEditorialAgent(agentKey: AgentKey, cycle: EditorialCycle, artifacts: EditorialArtifact[]): Promise<AgentResult> {
  const definition = agentDefinitions[agentKey];
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return demoResult(agentKey, cycle, artifacts);

  const tools = definition.usesWeb ? [{ type: 'web_search' }] : undefined;
  const longForm = agentKey === 'article_writer' || agentKey === 'podcast_producer';
  const baseInput = {
    cycle,
    artifacts: artifacts.map((item) => ({ kind: item.kind, version: item.version, content: item.content, sources: item.sources })),
  };
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: process.env.OPENAI_EDITORIAL_MODEL || 'gpt-5.4-mini',
      store: false,
      instructions: `${constitution}\nRegole di mercato aggiornate al 2026:\n${marketRulesForPrompt}\n\nRuolo: ${definition.name}.\n${definition.instructions}`,
      input: JSON.stringify(baseInput),
      tools,
      include: definition.usesWeb ? ['web_search_call.action.sources'] : undefined,
      reasoning: { effort: 'none' },
      text: { verbosity: longForm ? 'high' : 'medium', format: { type: 'json_schema', name: 'editorial_agent_output', strict: false, schema: OUTPUT_SCHEMA } },
      metadata: { workflow: 'holding_editorial', agent: agentKey, cycle_id: cycle.id },
      max_output_tokens: agentKey === 'podcast_producer' ? 14000 : agentKey === 'article_writer' ? 10000 : 7000,
    }),
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(`Servizio AI non disponibile (${response.status}): ${message.slice(0, 240)}`);
  }

  const payload = await response.json() as Record<string, unknown>;
  const parsed = JSON.parse(extractOutputText(payload)) as {
    summary: string;
    artifact_markdown: string;
    artifact: Record<string, unknown>;
    checks: string[];
    open_questions: string[];
    ready: boolean;
  };
  const artifact = parsed.artifact;
  if (!artifact || typeof artifact !== 'object' || Array.isArray(artifact)) {
    throw new Error('L’agente non ha restituito un contenuto editoriale strutturato.');
  }
  const lengthValidation = validateLengths(agentKey, artifact);
  if (lengthValidation.issues.length > 0) {
    throw new Error(`Contenuto non salvato: ${lengthValidation.issues.join('; ')}.`);
  }

  return {
    summary: parsed.summary,
    artifactMarkdown: parsed.artifact_markdown,
    artifact,
    checks: [...parsed.checks, ...lengthValidation.checks],
    openQuestions: parsed.open_questions,
    sources: extractSources(payload),
    ready: parsed.ready,
    mode: 'live',
  };
}

export async function generateIdeas(seed: string, category: string): Promise<AgentResult> {
  const now = new Date().toISOString();
  const cycle: EditorialCycle = {
    id: `ideas-${now}`,
    topic: seed || 'Vita quotidiana più gestibile',
    promise: '',
    category,
    state: 'selected',
    currentAgent: 'topic_scout',
    approvalStatus: 'pending',
    approvedVersion: null,
    approvedChannels: [],
    createdBy: 'studio',
    createdAt: now,
    updatedAt: now,
  };
  return runEditorialAgent('topic_scout', cycle, []);
}

function demoResult(agentKey: AgentKey, cycle: EditorialCycle, artifacts: EditorialArtifact[]): AgentResult {
  const topic = cycle.topic;
  const date = new Intl.DateTimeFormat('it-IT', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date());
  const slug = slugify(topic);
  const latest = (kind: string) => [...artifacts].reverse().find((item) => item.kind === kind)?.content || {};
  const article = latest('article') as { article?: Record<string, unknown>; newsletter_draft?: Record<string, unknown> };

  const base = { summary: '', artifactMarkdown: '', artifact: {}, checks: ['Struttura validata', 'Tono editoriale verificato'], openQuestions: [], ready: true, sources: [], mode: 'demo' as const };
  if (agentKey === 'topic_scout') return demoScoutResult(cycle, base);
  if (agentKey === 'editor_in_chief') return { ...base, summary: 'Brief editoriale definito.', artifactMarkdown: `# Brief\n\n**Tema:** ${topic}\n\nUna guida concreta per trasformare un problema quotidiano in un gesto sostenibile.`, artifact: { audience: 'Adulti con giornate dense e responsabilità sovrapposte', reader_problem: `Il tema “${topic}” viene percepito come troppo grande da affrontare`, promise: 'Una pratica piccola da provare in sette giorni', angle: 'Ridurre attrito e perfezionismo', primary_category: cycle.category, secondary_categories: ['Benessere', 'Organizzazione'], article_goal: 'Offrire una guida concreta', podcast_goal: 'Aggiungere voce, esempi e sfumature', newsletter_goal: 'Portare il lettore a una sola azione', call_to_action: 'Scegliere un esperimento per questa settimana', risks: ['Evitare promesse assolute'], success_metrics: ['Lettura oltre il 50%', 'Risposte alla newsletter', 'Completamento episodio'] } };
  if (agentKey === 'researcher') return { ...base, summary: 'Dossier dimostrativo preparato; la modalità live aggiungerà ricerca web e fonti correnti.', artifactMarkdown: `# Dossier\n\nIl dossier live raccoglierà fonti primarie e punti controversi per “${topic}”.`, artifact: { executive_summary: 'Le soluzioni sostenibili riducono decisioni e attriti invece di aggiungere disciplina.', key_findings: ['Partire da un singolo punto di attrito', 'Rendere visibile il confine scelto', 'Verificare dopo sette giorni'], claims: [], examples: ['Preparare una decisione ricorrente in anticipo'], counterpoints: ['Una routine non funziona allo stesso modo per tutte le famiglie'], unanswered_questions: ['Quale ostacolo è più frequente per il pubblico?'] }, openQuestions: ['Attivare OPENAI_API_KEY per una ricerca con fonti web aggiornate.'] };
  if (agentKey === 'article_writer') return { ...base, summary: 'Articolo e newsletter pronti per il podcast.', artifactMarkdown: `# ${topic}\n\nUna vita più gestibile comincia spesso da una decisione più piccola.`, artifact: { article: { slug, category: cycle.category, title: topic, description: 'Un modo concreto per creare spazio nelle giornate piene.', readingTime: '6 min di lettura', date, image: '/images/newsletter-hero.png', body: ['Quando una giornata è piena, aggiungere una nuova regola raramente aiuta. Il primo passo è osservare il punto in cui perdiamo più energia.', 'Scegli una sola decisione ricorrente e preparala in anticipo. Deve essere abbastanza piccola da funzionare anche in una settimana difficile.', 'Dopo sette giorni, non chiederti se hai seguito tutto alla perfezione. Chiediti se quella scelta ha ridotto almeno un po’ di attrito.'], seoTitle: topic, seoDescription: 'Una pratica sostenibile per rendere più gestibili le giornate piene.', sourceUrls: [] }, newsletter_draft: { subject: topic.slice(0, 58), previewText: 'Una sola pratica da provare questa settimana.', title: topic, introduction: 'Questa settimana partiamo da una decisione piccola.', sections: [{ title: 'Una cosa alla volta', paragraphs: ['Scegli il punto di maggiore attrito e riducilo di un passo.'] }], primaryCta: 'Leggi l’articolo completo' } } };
  if (agentKey === 'podcast_producer') return { ...base, summary: 'Pacchetto podcast video-first pronto per la registrazione.', artifactMarkdown: `# Podcast — ${topic}\n\nEpisodio video-first, comprensibile anche in solo audio.`, artifact: { slug, number: 'NUOVO', title: topic, date, duration: '28 min', description: 'Una conversazione concreta per alleggerire le giornate senza inseguire la perfezione.', image: '/images/podcast-hero.png', opening_hook: 'Qual è la decisione che continui a prendere ogni giorno e che potresti prendere una volta sola?', showNotes: ['Individuare il punto di attrito', 'Scegliere una pratica minima', 'Valutare senza perfezionismo'], chapters: [{ time: '00:00', title: 'La domanda iniziale' }, { time: '06:30', title: 'Dove perdiamo energia' }, { time: '16:00', title: 'Una pratica sostenibile' }, { time: '24:00', title: 'L’esperimento di sette giorni' }], script_sections: [{ title: 'Apertura', spoken_text: 'Ci sono decisioni che prendiamo così spesso da non vederle più.' }], links: [{ label: `Articolo: ${topic}`, url: `/articoli/${slug}` }], transcript: ['Ci sono decisioni che prendiamo così spesso da non vederle più.', 'Oggi ne scegliamo una e proviamo a renderla più leggera.'], spotify_clip: { hook: 'La tua giornata non ha bisogno di una nuova routine.', script: 'Ha bisogno di una decisione in meno. Ecco da dove partire.', duration_seconds: 35 }, youtube: { title: `${topic} | Una pratica da provare`, description: 'Una conversazione concreta con capitoli, fonti e una pratica finale.', thumbnail_text: 'UNA DECISIONE IN MENO', shorts: [{ hook: 'Non ti serve una routine perfetta', script: 'Scegli una decisione ricorrente e prendila una volta sola.' }] }, recording_checklist: ['Video 1080p 16:9', 'Audio pulito e comprensibile senza immagini', 'Apertura senza sigla lunga', 'Capitoli manuali', 'Clip verticale sottotitolata'] } };
  if (agentKey === 'reviewer') return { ...base, summary: 'Revisione superata in modalità dimostrativa.', artifactMarkdown: '# Revisione\n\nIl pacchetto è coerente, prudente e pronto per il controllo tecnico.', artifact: { verdict: 'pass', factual_findings: ['Nessuna affermazione quantitativa non supportata'], editorial_findings: ['Tono coerente e promessa mantenuta'], market_findings: ['Episodio video-first', 'Clip verticale prevista', 'Newsletter con una CTA'], legal_privacy_findings: ['Nessun dato personale'], required_changes: [], approved_claims: [] } };
  if (agentKey === 'site_manager_analyst') return { ...base, summary: cycle.state === 'published' ? 'Controllo post-pubblicazione pronto.' : 'Preflight completato.', artifactMarkdown: '# Controllo qualità\n\nNessun blocco tecnico nel pacchetto editoriale.', artifact: { phase: cycle.state === 'published' ? 'post_publish' : 'preflight', checks: ['Slug presente', 'Metadata presenti', 'CTA unica', 'Capitoli podcast presenti', 'Checklist newsletter conforme'], blockers: [], warnings: ['Le piattaforme esterne richiedono credenziali e controllo account'], metrics: {}, recommendations: ['Misurare risultati dopo 48 ore e 7 giorni'] } };
  if (agentKey === 'publisher') return { ...base, summary: 'Pacchetto di distribuzione preparato.', artifactMarkdown: '# Distribuzione\n\nSito pronto; Spotify, YouTube e newsletter seguono i canali approvati.', artifact: { site: { slug, status: 'ready' }, newsletter: { subject: article.newsletter_draft?.subject || topic, status: 'ready' }, spotify: { episode: topic, clip: 'ready', status: 'requires_account' }, youtube: { video: topic, shorts: 'ready', status: 'requires_account' }, preflight_checks: ['Versione approvata', 'Campi obbligatori presenti'], rollback_plan: 'Rimuovere i record pubblici del ciclo e sospendere gli invii esterni.' } };
  return base;
}

function slugify(value: string) {
  return value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 70) || 'nuovo-contenuto';
}

function demoScoutResult(cycle: EditorialCycle, base: AgentResult): AgentResult {
  const topic = cycle.topic.trim();
  const lower = topic.toLowerCase();
  const familyOverload = /(figli?|bambin|piange|moglie|marito|famiglia|casa|stress)/.test(lower);
  const money = /(sold|budget|spes|risparmi|mutuo|bollett|stipend)/.test(lower);
  const work = /(lavor|colleg|email|messagg|riunion|ufficio|capo)/.test(lower);
  const theme = familyOverload ? 'le giornate in cui la famiglia è sotto pressione' : money ? 'le decisioni economiche quotidiane' : work ? 'il confine tra lavoro e vita personale' : topic || 'le giornate troppo piene';
  const inferredCategory = familyOverload ? 'Famiglia' : money ? 'Soldi' : work ? 'Lavoro' : cycle.category;
  const candidates = [
    ['Quando tutto arriva insieme: da dove si parte?', 'Stabilire una priorità condivisa senza pretendere di risolvere tutto.', 'Una mappa delle prime due mosse', 'Conversazione su una giornata reale'],
    ['La lista di ciò che oggi può aspettare', 'Ridurre consapevolmente il carico invece di organizzarlo soltanto meglio.', 'Esercizio pratico di sottrazione', 'Esperimento raccontato passo passo'],
    ['Prima la calma, poi il piano', 'Separare il momento di tensione dal momento in cui si prendono decisioni.', 'Guida per riconoscere le due fasi', 'Esempi di frasi da usare'],
    ['Il piano minimo per le giornate storte', 'Preparare una versione essenziale della giornata che funzioni anche con poca energia.', 'Metodo con tre livelli di priorità', 'Diario di una settimana imperfetta'],
    ['Non serve dividersi tutto a metà', 'Rendere visibile il carico e distribuirlo in modo sostenibile, non matematico.', 'Schema per una conversazione concreta', 'Dialogo tra punti di vista diversi'],
    ['La transizione che decide il resto della serata', 'Proteggere un singolo passaggio critico invece di riprogettare l’intera giornata.', 'Esperimento di sette giorni', 'Racconto prima e dopo'],
    ['Abbastanza fatto: il confine che protegge la famiglia', 'Definire in anticipo che cosa significa “sufficiente” quando le richieste si accumulano.', 'Checklist abbastanza buona', 'Conversazione su aspettative e realtà'],
    ['Cosa dire quando la tensione sale', 'Usare parole brevi e non accusatorie per rallentare il conflitto.', 'Cinque frasi utilizzabili', 'Esempi dialogati'],
    ['Il costo nascosto delle decisioni ripetute', 'Individuare le scelte che consumano energia ogni giorno e prepararne una in anticipo.', 'Audit delle decisioni domestiche', 'Storie di piccoli automatismi'],
    ['Una cosa in meno, non una routine in più', 'Togliere un attrito concreto prima di aggiungere nuove abitudini.', 'Guida alla semplificazione', 'Sfida pratica per gli ascoltatori'],
  ] as const;
  const start = hash(`${cycle.id}-${topic}`) % candidates.length;
  const ideas = Array.from({ length: 5 }, (_, index) => candidates[(start + index * 3) % candidates.length]).map((candidate, index) => ({
    title: candidate[0],
    reader_question: index === 0 ? `Come affrontare ${theme} senza dover risolvere cento cose insieme?` : `Quale cambiamento concreto può rendere più gestibile ${theme}?`,
    why_now: `${candidate[1]} La proposta nasce dalla situazione descritta: “${topic.slice(0, 150)}”.`,
    category: index === 1 && familyOverload ? cycle.category : inferredCategory,
    angle: candidate[1],
    article_potential: candidate[2],
    podcast_potential: candidate[3],
    newsletter_potential: index % 2 === 0 ? 'Una domanda e un esercizio breve' : 'Checklist da provare per sette giorni',
    risk_level: /conflitto|tensione|economiche/.test(candidate[1]) ? 'medium' : 'low',
  }));
  return {
    ...base,
    summary: 'Cinque opportunità diverse costruite sulla domanda inserita.',
    artifactMarkdown: `# Idee editoriali\n\nCinque angoli pratici e distinti collegati a ${theme}.`,
    artifact: { ideas },
  };
}

function hash(value: string) {
  let result = 2166136261;
  for (let index = 0; index < value.length; index += 1) result = Math.imul(result ^ value.charCodeAt(index), 16777619);
  return result >>> 0;
}
