import { isAuthorizedEditor } from '@/app/chatgpt-auth';

export type EditorIdentity = { userId: string; email: string; displayName: string };

export function editorFromRequest(request: Request): EditorIdentity | null {
  if (process.env.NODE_ENV !== 'production') return { userId: 'local-editor', email: 'locale@holding.test', displayName: 'Editor locale' };
  const userId = request.headers.get('oai-authenticated-user-id');
  const email = request.headers.get('oai-authenticated-user-email');
  if (!userId || !email || !isAuthorizedEditor({ userId, email })) return null;
  return { userId, email, displayName: email };
}

export function unauthorizedResponse() {
  return Response.json({ error: 'Accesso riservato alla redazione.' }, { status: 401 });
}
