export const marketPlaybook = {
  updatedAt: '2026-09-09',
  formats: {
    title: 'Standard editoriali: profondità senza riempitivi',
    rules: [
      'Articolo: obiettivo 1.600 parole, intervallo obbligatorio 1.400–1.900.',
      'Newsletter: obiettivo 300 parole, intervallo obbligatorio 220–380 e una sola CTA.',
      'Podcast: obiettivo 3.400 parole, intervallo obbligatorio 3.000–3.800, pari a circa 21–27 minuti.',
      'Clip Spotify e YouTube: 60–110 parole, circa 30–45 secondi.',
      'La lunghezza è un controllo editoriale; utilità, intento e retention restano i criteri decisivi.',
    ],
    sources: [
      { label: 'Google — contenuti utili', url: 'https://developers.google.com/search/docs/fundamentals/creating-helpful-content' },
      { label: 'YouTube — retention', url: 'https://support.google.com/youtube/answer/9314415?hl=en' },
      { label: 'Spotify — performance episodi', url: 'https://creators.spotify.com/resources/grow/understanding-your-episode-performance' },
      { label: 'beehiiv — lunghezza newsletter', url: 'https://www.beehiiv.com/blog/how-long-should-a-newsletter-be' },
    ],
  },
  spotify: {
    title: 'Spotify: video-first, audio-everywhere',
    rules: [
      'Un episodio video 16:9 settimanale che funzioni perfettamente anche in solo audio.',
      'Apertura con promessa o domanda nei primi secondi; niente sigla lunga.',
      'Un Clip verticale nativo da 15–90 secondi con sottotitoli e hook entro 3–7 secondi.',
      'Almeno tre capitoli manuali e trascrizione SRT/VTT per ogni episodio italiano.',
      'Misurare conversione impression→play, consumo medio, completamento, ritorno e plays dai Clip.',
      'Non basare il piano economico iniziale sul Partner Program Spotify in Italia.',
    ],
    sources: [
      { label: 'Spotify Clips', url: 'https://support.spotify.com/uk/creators/article/clips/' },
      { label: 'Specifiche video', url: 'https://support.spotify.com/us/creators/article/video-specs/' },
      { label: 'Analytics', url: 'https://support.spotify.com/us/creators/article/engagement-analytics/' },
    ],
  },
  youtube: {
    title: 'YouTube: episodio nativo + Shorts',
    rules: [
      'Pubblicare l’episodio completo in 16:9 con conduttore visibile e audio pulito.',
      'Usare una playlist contrassegnata come podcast contenente soltanto episodi integrali.',
      'Creare Shorts verticali autonomi e collegarli all’episodio completo tramite Related video.',
      'Thumbnail episodio specifica 16:9, titolo con il valore principale all’inizio e descrizione unica.',
      'Usare capitoli, fonti e call to action nelle descrizioni; i tag sono secondari.',
      'Ottimizzare watch time e soddisfazione, non il solo CTR.',
    ],
    sources: [
      { label: 'Podcast su YouTube', url: 'https://support.google.com/youtube/answer/12751636?hl=en' },
      { label: 'RSS per podcast', url: 'https://support.google.com/youtube/answer/13525207?hl=en' },
      { label: 'A/B test', url: 'https://support.google.com/youtube/answer/16391400?hl=en-GB' },
    ],
  },
  newsletter: {
    title: 'Newsletter: fiducia, consenso e risposta',
    rules: [
      'Cadenza settimanale prevedibile e una sola CTA primaria.',
      'Double opt-in, prova del consenso e disiscrizione one-click entro 48 ore.',
      'SPF, DKIM e DMARC fin dal primo invio; mittente e dominio stabili.',
      'Open tracking individuale disattivato senza consenso separato, in linea con le regole italiane 2026.',
      'Valutare clic unici depurati dai bot, risposte, conversioni, bounce e reclami.',
      'Oggetto descrittivo e breve, preview text complementare, contenuto mobile-first.',
    ],
    sources: [
      { label: 'Gmail sender requirements', url: 'https://support.google.com/mail/answer/81126?hl=en' },
      { label: 'Gmail subscription guidelines', url: 'https://support.google.com/mail/answer/15263077?hl=en' },
      { label: 'Garante — tracking pixel', url: 'https://www.garanteprivacy.it/home/docweb/-/docweb-display/docweb/10241943' },
    ],
  },
} as const;

export const marketRulesForPrompt = [
  ...marketPlaybook.formats.rules.map((rule) => `Formato: ${rule}`),
  ...marketPlaybook.spotify.rules.map((rule) => `Spotify: ${rule}`),
  ...marketPlaybook.youtube.rules.map((rule) => `YouTube: ${rule}`),
  ...marketPlaybook.newsletter.rules.map((rule) => `Newsletter: ${rule}`),
].join('\n');
