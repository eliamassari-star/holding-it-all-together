import { articles as seededArticles, categories, newsletterIssues as seededIssues, podcastEpisodes as seededEpisodes } from '@/app/data/content';
import type { Article, NewsletterIssue, PodcastEpisode } from '@/app/data/content';
import { getPublishedRecords } from './repository';

function mergeBySlug<T extends { slug: string }>(fresh: T[], seeded: T[]) {
  const map = new Map<string, T>();
  [...fresh, ...seeded].forEach((item) => { if (!map.has(item.slug)) map.set(item.slug, item); });
  return [...map.values()];
}

export async function getArticles() {
  return mergeBySlug(await getPublishedRecords<Article>('article'), seededArticles);
}

export async function getArticle(slug: string) {
  return (await getArticles()).find((item) => item.slug === slug);
}

export async function getNewsletterIssues() {
  return mergeBySlug(await getPublishedRecords<NewsletterIssue>('newsletter'), seededIssues);
}

export async function getNewsletterIssue(slug: string) {
  return (await getNewsletterIssues()).find((item) => item.slug === slug);
}

export async function getPodcastEpisodes() {
  return mergeBySlug(await getPublishedRecords<PodcastEpisode>('podcast'), seededEpisodes);
}

export async function getPodcastEpisode(slug: string) {
  return (await getPodcastEpisodes()).find((item) => item.slug === slug);
}

export { categories };
