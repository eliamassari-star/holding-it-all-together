import { ensureDatabase, getDatabase } from '@/db';
import { agentDefinitions, nextStateAfterAgent, workflowAgentForState } from './agents';
import type { AgentKey, AgentResult, AgentRun, CyclePackage, CycleState, EditorialArtifact, EditorialCycle, PublicationChannel } from './types';

type CycleRow = {
  id: string; topic: string; promise: string; category: string; state: CycleState; current_agent: AgentKey | null;
  approval_status: 'pending' | 'approved' | 'rejected'; approved_version: number | null; approved_channels: string;
  created_by: string; created_at: string; updated_at: string;
};
type ArtifactRow = {
  id: string; cycle_id: string; kind: string; version: number; status: string; content_markdown: string; content_json: string;
  sources_json: string; created_by: string; created_at: string;
};
type RunRow = { id: string; cycle_id: string; agent_key: AgentKey; status: string; summary: string; error: string | null; created_at: string; completed_at: string | null };

const now = () => new Date().toISOString();
const parseJson = <T>(value: string, fallback: T): T => { try { return JSON.parse(value) as T; } catch { return fallback; } };

function mapCycle(row: CycleRow): EditorialCycle {
  return { id: row.id, topic: row.topic, promise: row.promise, category: row.category, state: row.state, currentAgent: row.current_agent || workflowAgentForState[row.state] || null, approvalStatus: row.approval_status, approvedVersion: row.approved_version, approvedChannels: parseJson(row.approved_channels, []), createdBy: row.created_by, createdAt: row.created_at, updatedAt: row.updated_at };
}

function mapArtifact(row: ArtifactRow): EditorialArtifact {
  return { id: row.id, cycleId: row.cycle_id, kind: row.kind, version: row.version, status: row.status, contentMarkdown: row.content_markdown, content: parseJson(row.content_json, {}), sources: parseJson(row.sources_json, []), createdBy: row.created_by, createdAt: row.created_at };
}

function mapRun(row: RunRow): AgentRun {
  return { id: row.id, cycleId: row.cycle_id, agentKey: row.agent_key, status: row.status, summary: row.summary, error: row.error, createdAt: row.created_at, completedAt: row.completed_at };
}

export async function listCycles(): Promise<EditorialCycle[]> {
  await ensureDatabase();
  const result = await getDatabase().prepare('SELECT * FROM editorial_cycles ORDER BY updated_at DESC LIMIT 100').all<CycleRow>();
  return result.results.map(mapCycle);
}

export async function createCycle(input: { topic: string; category: string; promise?: string }, actor: string) {
  await ensureDatabase();
  const timestamp = now();
  const id = `${timestamp.slice(0, 10)}-${crypto.randomUUID().slice(0, 8)}`;
  await getDatabase().prepare(`INSERT INTO editorial_cycles (id, topic, promise, category, state, current_agent, approval_status, approved_channels, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, 'selected', 'editor_in_chief', 'pending', '[]', ?, ?, ?)`).bind(id, input.topic.trim(), input.promise?.trim() || '', input.category, actor, timestamp, timestamp).run();
  return getCyclePackage(id);
}

export async function getCyclePackage(id: string): Promise<CyclePackage> {
  await ensureDatabase();
  const database = getDatabase();
  const [cycleResult, artifactResult, runResult, publicationResult] = await Promise.all([
    database.prepare('SELECT * FROM editorial_cycles WHERE id = ?').bind(id).first<CycleRow>(),
    database.prepare('SELECT * FROM editorial_artifacts WHERE cycle_id = ? ORDER BY created_at ASC').bind(id).all<ArtifactRow>(),
    database.prepare('SELECT * FROM agent_runs WHERE cycle_id = ? ORDER BY created_at DESC').bind(id).all<RunRow>(),
    database.prepare('SELECT channel, status, url, created_at FROM publication_events WHERE cycle_id = ? ORDER BY created_at DESC').bind(id).all<{ channel: string; status: string; url: string | null; created_at: string }>(),
  ]);
  if (!cycleResult) throw new Error('Ciclo editoriale non trovato.');
  return {
    cycle: mapCycle(cycleResult),
    artifacts: artifactResult.results.map(mapArtifact),
    runs: runResult.results.map(mapRun),
    publicationEvents: publicationResult.results.map((row) => ({ channel: row.channel, status: row.status, url: row.url, createdAt: row.created_at })),
  };
}

export async function beginAgentRun(cycleId: string, agentKey: AgentKey) {
  await ensureDatabase();
  const id = crypto.randomUUID();
  const timestamp = now();
  await getDatabase().batch([
    getDatabase().prepare(`INSERT INTO agent_runs (id, cycle_id, agent_key, status, created_at) VALUES (?, ?, ?, 'running', ?)`).bind(id, cycleId, agentKey, timestamp),
    getDatabase().prepare('UPDATE editorial_cycles SET current_agent = ?, updated_at = ? WHERE id = ?').bind(agentKey, timestamp, cycleId),
  ]);
  return id;
}

export async function completeAgentRun(cycleId: string, runId: string, agentKey: AgentKey, result: AgentResult) {
  await ensureDatabase();
  const database = getDatabase();
  const versionRow = await database.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM editorial_artifacts WHERE cycle_id = ? AND kind = ?').bind(cycleId, agentDefinitions[agentKey].artifactKind).first<{ version: number }>();
  const version = (versionRow?.version || 0) + 1;
  let nextState = nextStateAfterAgent(agentKey, (await getCyclePackage(cycleId)).cycle.state);
  if (agentKey === 'reviewer' && result.artifact.verdict === 'changes_requested') nextState = 'changes_requested';
  const timestamp = now();
  await database.batch([
    database.prepare(`INSERT INTO editorial_artifacts (id, cycle_id, kind, version, status, content_markdown, content_json, sources_json, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(crypto.randomUUID(), cycleId, agentDefinitions[agentKey].artifactKind, version, result.ready ? 'complete' : 'needs_attention', result.artifactMarkdown, JSON.stringify({ ...result.artifact, _checks: result.checks, _openQuestions: result.openQuestions, _mode: result.mode }), JSON.stringify(result.sources), agentKey, timestamp),
    database.prepare(`UPDATE agent_runs SET status = 'completed', summary = ?, completed_at = ? WHERE id = ?`).bind(result.summary, timestamp, runId),
    database.prepare(`UPDATE editorial_cycles SET state = ?, current_agent = ?, approval_status = 'pending', approved_version = NULL, approved_channels = '[]', updated_at = ? WHERE id = ?`).bind(nextState, workflowAgentForState[nextState] || null, timestamp, cycleId),
  ]);
  return getCyclePackage(cycleId);
}

export async function failAgentRun(cycleId: string, runId: string, message: string) {
  const timestamp = now();
  await getDatabase().batch([
    getDatabase().prepare(`UPDATE agent_runs SET status = 'failed', error = ?, completed_at = ? WHERE id = ?`).bind(message, timestamp, runId),
    getDatabase().prepare('UPDATE editorial_cycles SET current_agent = (SELECT agent_key FROM agent_runs WHERE id = ?), updated_at = ? WHERE id = ?').bind(runId, timestamp, cycleId),
  ]);
}

export async function approveCycle(cycleId: string, channels: PublicationChannel[], notes: string, actor: string) {
  const pack = await getCyclePackage(cycleId);
  if (pack.cycle.state !== 'ready_for_approval') throw new Error('Il ciclo non è pronto per l’approvazione.');
  if (!channels.length) throw new Error('Seleziona almeno un canale.');
  const version = Math.max(...pack.artifacts.map((item) => item.version), 1);
  const timestamp = now();
  await getDatabase().batch([
    getDatabase().prepare(`INSERT INTO approval_events (id, cycle_id, version, decision, channels_json, notes, actor, created_at) VALUES (?, ?, ?, 'approved', ?, ?, ?, ?)`).bind(crypto.randomUUID(), cycleId, version, JSON.stringify(channels), notes.trim(), actor, timestamp),
    getDatabase().prepare(`UPDATE editorial_cycles SET state = 'approved', current_agent = 'publisher', approval_status = 'approved', approved_version = ?, approved_channels = ?, updated_at = ? WHERE id = ?`).bind(version, JSON.stringify(channels), timestamp, cycleId),
  ]);
  return getCyclePackage(cycleId);
}

export async function publishApprovedCycle(cycleId: string, distribution: AgentResult, actor: string) {
  const pack = await getCyclePackage(cycleId);
  if (pack.cycle.state !== 'approved' || pack.cycle.approvalStatus !== 'approved') throw new Error('Serve un’approvazione valida prima della pubblicazione.');
  const articleArtifact = [...pack.artifacts].reverse().find((item) => item.kind === 'article');
  const podcastArtifact = [...pack.artifacts].reverse().find((item) => item.kind === 'podcast');
  if (!articleArtifact || !podcastArtifact) throw new Error('Il pacchetto non contiene articolo e podcast.');

  const article = articleArtifact.content.article as Record<string, unknown> | undefined;
  const newsletterDraft = articleArtifact.content.newsletter_draft as Record<string, unknown> | undefined;
  const podcast = podcastArtifact.content;
  if (!article || typeof article.slug !== 'string' || typeof podcast.slug !== 'string') throw new Error('Slug pubblico mancante.');

  const timestamp = now();
  const channels = pack.cycle.approvedChannels;
  const statements: D1PreparedStatement[] = [];
  if (channels.includes('site')) {
    const issueSlug = `${article.slug}-lettera`;
    const newsletter = {
      slug: issueSlug,
      number: '#NUOVO',
      date: article.date,
      title: newsletterDraft?.title || article.title,
      subtitle: newsletterDraft?.previewText || article.description,
      introduction: newsletterDraft?.introduction || article.description,
      heroImage: article.image || '/images/newsletter-hero.png',
      author: 'Redazione Holding It All Together',
      seoTitle: article.seoTitle || article.title,
      seoDescription: article.seoDescription || article.description,
      sections: newsletterDraft?.sections || [],
      linkedArticles: [article.slug],
    };
    for (const [type, slug, content] of [['article', article.slug, article], ['podcast', podcast.slug, podcast], ['newsletter', issueSlug, newsletter]] as const) {
      statements.push(getDatabase().prepare(`INSERT INTO published_content (id, content_type, slug, cycle_id, content_json, published_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(content_type, slug) DO UPDATE SET content_json = excluded.content_json, cycle_id = excluded.cycle_id, updated_at = excluded.updated_at`).bind(crypto.randomUUID(), type, slug, cycleId, JSON.stringify(content), timestamp, timestamp));
    }
  }
  for (const channel of channels) {
    const status = channel === 'site' ? 'published' : 'package_ready';
    statements.push(getDatabase().prepare('INSERT INTO publication_events (id, cycle_id, channel, status, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?)').bind(crypto.randomUUID(), cycleId, channel, status, JSON.stringify(distribution.artifact), timestamp));
  }
  const versionRow = await getDatabase().prepare('SELECT COALESCE(MAX(version), 0) AS version FROM editorial_artifacts WHERE cycle_id = ? AND kind = ?').bind(cycleId, 'distribution').first<{ version: number }>();
  statements.push(getDatabase().prepare(`INSERT INTO editorial_artifacts (id, cycle_id, kind, version, status, content_markdown, content_json, sources_json, created_by, created_at) VALUES (?, ?, 'distribution', ?, 'complete', ?, ?, '[]', ?, ?)`).bind(crypto.randomUUID(), cycleId, (versionRow?.version || 0) + 1, distribution.artifactMarkdown, JSON.stringify({ ...distribution.artifact, _mode: distribution.mode }), actor, timestamp));
  statements.push(getDatabase().prepare(`UPDATE editorial_cycles SET state = 'published', current_agent = 'site_manager_analyst', updated_at = ? WHERE id = ?`).bind(timestamp, cycleId));
  await getDatabase().batch(statements);

  await sendPublicationWebhook({ cycle: pack.cycle, article, podcast, newsletter: newsletterDraft, distribution: distribution.artifact, channels });
  return getCyclePackage(cycleId);
}

async function sendPublicationWebhook(payload: Record<string, unknown>) {
  const url = process.env.EDITORIAL_PUBLISH_WEBHOOK_URL;
  if (!url) return;
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(process.env.EDITORIAL_PUBLISH_WEBHOOK_TOKEN ? { Authorization: `Bearer ${process.env.EDITORIAL_PUBLISH_WEBHOOK_TOKEN}` } : {}) },
      body: JSON.stringify(payload),
    });
    if (!response.ok) console.warn(`Webhook di pubblicazione non riuscito (${response.status}).`);
  } catch (error) {
    console.warn('Webhook di pubblicazione non raggiungibile.', error instanceof Error ? error.message : 'errore sconosciuto');
  }
}

export async function getPublishedRecords<T>(contentType: 'article' | 'podcast' | 'newsletter'): Promise<T[]> {
  try {
    await ensureDatabase();
    const result = await getDatabase().prepare('SELECT content_json FROM published_content WHERE content_type = ? ORDER BY published_at DESC').bind(contentType).all<{ content_json: string }>();
    return result.results.map((row) => parseJson<T | null>(row.content_json, null)).filter((item): item is T => item !== null);
  } catch {
    return [];
  }
}
