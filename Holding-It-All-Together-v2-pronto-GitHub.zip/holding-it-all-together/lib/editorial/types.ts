export type AgentKey =
  | 'editor_in_chief'
  | 'topic_scout'
  | 'researcher'
  | 'article_writer'
  | 'podcast_producer'
  | 'reviewer'
  | 'publisher'
  | 'site_manager_analyst';

export type CycleState =
  | 'selected'
  | 'brief_ready'
  | 'research_ready'
  | 'article_ready'
  | 'podcast_ready'
  | 'review_ready'
  | 'changes_requested'
  | 'ready_for_approval'
  | 'approved'
  | 'published'
  | 'archived';

export type PublicationChannel = 'site' | 'newsletter' | 'podcast_bundle';

export type EditorialCycle = {
  id: string;
  topic: string;
  promise: string;
  category: string;
  state: CycleState;
  currentAgent: AgentKey | null;
  approvalStatus: 'pending' | 'approved' | 'rejected';
  approvedVersion: number | null;
  approvedChannels: PublicationChannel[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
};

export type EditorialArtifact = {
  id: string;
  cycleId: string;
  kind: string;
  version: number;
  status: string;
  contentMarkdown: string;
  content: Record<string, unknown>;
  sources: Array<{ title: string; url: string }>;
  createdBy: string;
  createdAt: string;
};

export type AgentRun = {
  id: string;
  cycleId: string;
  agentKey: AgentKey;
  status: string;
  summary: string;
  error: string | null;
  createdAt: string;
  completedAt: string | null;
};

export type CyclePackage = {
  cycle: EditorialCycle;
  artifacts: EditorialArtifact[];
  runs: AgentRun[];
  publicationEvents: Array<{ channel: string; status: string; url: string | null; createdAt: string }>;
};

export type AgentResult = {
  summary: string;
  artifactMarkdown: string;
  artifact: Record<string, unknown>;
  checks: string[];
  openQuestions: string[];
  sources: Array<{ title: string; url: string }>;
  ready: boolean;
  mode: 'live' | 'demo';
};
