import { ensureDatabase, getDatabase } from '@/db';

export async function recordConsent(input: { email: string; event: 'subscription_requested' | 'preferences_updated' | 'unsubscribed'; source: string; trackingConsent: boolean }) {
  try {
    await ensureDatabase();
    await getDatabase().prepare('INSERT INTO newsletter_consents (id, email, event, source, privacy_version, tracking_consent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').bind(crypto.randomUUID(), input.email, input.event, input.source, process.env.NEWSLETTER_PRIVACY_VERSION || '2026-09-08', input.trackingConsent ? 1 : 0, new Date().toISOString()).run();
    if (input.event === 'unsubscribed') {
      await getDatabase().prepare(`INSERT INTO newsletter_suppressions (email, reason, created_at) VALUES (?, 'user_request', ?) ON CONFLICT(email) DO UPDATE SET reason = excluded.reason, created_at = excluded.created_at`).bind(input.email, new Date().toISOString()).run();
    }
  } catch (error) {
    console.warn('Consent log unavailable', error instanceof Error ? error.message : 'unknown');
  }
}

export async function isSuppressed(email: string) {
  try {
    await ensureDatabase();
    return Boolean(await getDatabase().prepare('SELECT email FROM newsletter_suppressions WHERE email = ?').bind(email).first());
  } catch { return false; }
}

function bytesToBase64Url(bytes: Uint8Array) {
  let value = '';
  bytes.forEach((byte) => { value += String.fromCharCode(byte); });
  return btoa(value).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/g, '');
}

function base64UrlToBytes(value: string) {
  const padded = value.replaceAll('-', '+').replaceAll('_', '/') + '='.repeat((4 - value.length % 4) % 4);
  const decoded = atob(padded);
  return Uint8Array.from(decoded, (character) => character.charCodeAt(0));
}

async function signature(payload: string) {
  const secret = process.env.NEWSLETTER_SIGNING_SECRET;
  if (!secret) throw new Error('Firma newsletter non configurata.');
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return bytesToBase64Url(new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(payload))));
}

export async function createUnsubscribeToken(email: string) {
  const payload = bytesToBase64Url(new TextEncoder().encode(email.toLowerCase()));
  return `${payload}.${await signature(payload)}`;
}

export async function verifyUnsubscribeToken(token: string) {
  const [payload, supplied] = token.split('.');
  if (!payload || !supplied) return null;
  const secret = process.env.NEWSLETTER_SIGNING_SECRET;
  if (!secret) return null;
  try {
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
    const isValid = await crypto.subtle.verify('HMAC', key, base64UrlToBytes(supplied), new TextEncoder().encode(payload));
    if (!isValid) return null;
  } catch { return null; }
  try { return new TextDecoder().decode(base64UrlToBytes(payload)); } catch { return null; }
}
