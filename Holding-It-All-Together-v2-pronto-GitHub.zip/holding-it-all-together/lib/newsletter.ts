export type Subscriber = { email: string; name?: string; trackingConsent?: boolean };
export type NewsletterAction = 'preferences' | 'unsubscribe';

type Provider = 'mock' | 'beehiiv' | 'brevo' | 'mailchimp';

function provider(): Provider {
  const value = (process.env.NEWSLETTER_PROVIDER || 'mock').toLowerCase();
  return value === 'beehiiv' || value === 'brevo' || value === 'mailchimp' ? value : 'mock';
}

async function checkedFetch(url: string, init: RequestInit) {
  const response = await fetch(url, init);
  if (!response.ok) {
    const detail = await response.text();
    console.error('Newsletter provider error', response.status, detail.slice(0, 240));
    throw new Error('Il servizio newsletter non è disponibile. Riprova tra poco.');
  }
}

export async function subscribe(input: Subscriber) {
  const selected = provider();
  if (selected === 'mock') return { provider: selected, pending: true };

  if (selected === 'beehiiv') {
    const apiKey = process.env.BEEHIIV_API_KEY;
    const publicationId = process.env.BEEHIIV_PUBLICATION_ID;
    if (!apiKey || !publicationId) throw new Error('Configurazione newsletter incompleta.');
    await checkedFetch(`https://api.beehiiv.com/v2/publications/${publicationId}/subscriptions`, {
      method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: input.email, reactivate_existing: false, send_welcome_email: false, double_opt_override: 'on', utm_source: 'website', custom_fields: input.name ? [{ name: 'First Name', value: input.name }] : [] }),
    });
  }

  if (selected === 'brevo') {
    const apiKey = process.env.BREVO_API_KEY;
    const listId = Number(process.env.BREVO_LIST_ID);
    const templateId = Number(process.env.BREVO_DOI_TEMPLATE_ID);
    const redirectionUrl = process.env.BREVO_DOI_REDIRECT_URL;
    if (!apiKey || !listId) throw new Error('Configurazione newsletter incompleta.');
    const useDoi = Boolean(templateId && redirectionUrl);
    await checkedFetch(useDoi ? 'https://api.brevo.com/v3/contacts/doubleOptinConfirmation' : 'https://api.brevo.com/v3/contacts', {
      method: 'POST', headers: { 'api-key': apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify(useDoi ? { email: input.email, attributes: input.name ? { FIRSTNAME: input.name } : {}, includeListIds: [listId], templateId, redirectionUrl } : { email: input.email, attributes: input.name ? { FIRSTNAME: input.name } : {}, listIds: [listId], updateEnabled: true }),
    });
  }

  if (selected === 'mailchimp') {
    const apiKey = process.env.MAILCHIMP_API_KEY;
    const server = process.env.MAILCHIMP_SERVER_PREFIX;
    const listId = process.env.MAILCHIMP_LIST_ID;
    if (!apiKey || !server || !listId) throw new Error('Configurazione newsletter incompleta.');
    await checkedFetch(`https://${server}.api.mailchimp.com/3.0/lists/${listId}/members`, {
      method: 'POST', headers: { Authorization: `Basic ${btoa(`holding:${apiKey}`)}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email_address: input.email, status: 'pending', merge_fields: input.name ? { FNAME: input.name } : {} }),
    });
  }

  return { provider: selected, pending: true };
}

export async function accountAction(action: NewsletterAction, payload: Record<string, unknown>) {
  const webhook = process.env.NEWSLETTER_ACCOUNT_WEBHOOK_URL;
  if (!webhook) return { provider: 'mock', action };
  await checkedFetch(webhook, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(process.env.NEWSLETTER_ACCOUNT_WEBHOOK_TOKEN ? { Authorization: `Bearer ${process.env.NEWSLETTER_ACCOUNT_WEBHOOK_TOKEN}` } : {}) }, body: JSON.stringify({ action, ...payload }) });
  return { provider: 'webhook', action };
}
